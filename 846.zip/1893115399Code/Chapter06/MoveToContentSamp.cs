using System;
using System.IO;
using System.Xml;

public class Sample
{
	public static void Main()
	{

		// Load a document fragment
		XmlDocument xmlDoc = new XmlDocument();
		xmlDoc.LoadXml("<book genre='programming'> <title>ADO.NET Programming</title> </book>");

		XmlNode root = doc.DocumentElement;

		// Create a new file c:\xmlWriterTest.xml
		XmlTextWriter writer = new XmlTextWriter(xmlDoc, Console.Out);
		
		XmlTextReader reader = new XmlTextReader();

			//Remove all attribute and child nodes.
			root.RemoveAll();

		Console.WriteLine("Display the modified XML...");
		xmlDoc.Save(Console.Out);

	}
}
