using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DataAdapterSamp1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		private System.Data.SqlClient.SqlConnection sqlConnection1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
					/// the contents of this method with the code editor.
					/// </summary>
					private void InitializeComponent()
								{
						this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
						this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
						this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
						this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
						this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
						this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
						this.dataGrid1 = new System.Windows.Forms.DataGrid();
						((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
						this.SuspendLayout();
						// 
						// sqlDataAdapter1
						// 
						this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
						this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
						this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
						this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																												  new System.Data.Common.DataTableMapping("Table", "Employees", new System.Data.Common.DataColumnMapping[] {
																																																							   new System.Data.Common.DataColumnMapping("EmployeeID", "EmployeeID"),
																																																							   new System.Data.Common.DataColumnMapping("LastName", "LastName"),
																																																							   new System.Data.Common.DataColumnMapping("FirstName", "FirstName")})});
						this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
						// 
						// sqlDeleteCommand1
						// 
						this.sqlDeleteCommand1.CommandText = "DELETE FROM Employees WHERE (EmployeeID = @Original_EmployeeID) AND (FirstName = " +
							"@Original_FirstName) AND (LastName = @Original_LastName)";
						this.sqlDeleteCommand1.Connection = this.sqlConnection1;
						this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_EmployeeID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "EmployeeID", System.Data.DataRowVersion.Original, null));
						this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_FirstName", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "FirstName", System.Data.DataRowVersion.Original, null));
						this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_LastName", System.Data.SqlDbType.NVarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastName", System.Data.DataRowVersion.Original, null));
						// 
						// sqlConnection1
						// 
						this.sqlConnection1.ConnectionString = "data source=G61LS;initial catalog=Northwind;integrated security=SSPI;persist secu" +
							"rity info=False;workstation id=G61LS;packet size=4096";
						// 
						// sqlInsertCommand1
						// 
						this.sqlInsertCommand1.CommandText = "INSERT INTO Employees(LastName, FirstName) VALUES (@LastName, @FirstName); SELECT" +
							" EmployeeID, LastName, FirstName FROM Employees WHERE (EmployeeID = @@IDENTITY)";
						this.sqlInsertCommand1.Connection = this.sqlConnection1;
						this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastName", System.Data.SqlDbType.NVarChar, 20, "LastName"));
						this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@FirstName", System.Data.SqlDbType.NVarChar, 10, "FirstName"));
						// 
						// sqlSelectCommand1
						// 
						this.sqlSelectCommand1.CommandText = "SELECT EmployeeID, LastName, FirstName FROM Employees";
						this.sqlSelectCommand1.Connection = this.sqlConnection1;
						// 
						// sqlUpdateCommand1
						// 
						this.sqlUpdateCommand1.CommandText = @"UPDATE Employees SET LastName = @LastName, FirstName = @FirstName WHERE (EmployeeID = @Original_EmployeeID) AND (FirstName = @Original_FirstName) AND (LastName = @Original_LastName); SELECT EmployeeID, LastName, FirstName FROM Employees WHERE (EmployeeID = @EmployeeID)";
						this.sqlUpdateCommand1.Connection = this.sqlConnection1;
						this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastName", System.Data.SqlDbType.NVarChar, 20, "LastName"));
						this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@FirstName", System.Data.SqlDbType.NVarChar, 10, "FirstName"));
						this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_EmployeeID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "EmployeeID", System.Data.DataRowVersion.Original, null));
						this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_FirstName", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "FirstName", System.Data.DataRowVersion.Original, null));
						this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_LastName", System.Data.SqlDbType.NVarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastName", System.Data.DataRowVersion.Original, null));
						this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@EmployeeID", System.Data.SqlDbType.Int, 4, "EmployeeID"));
						// 
						// dataGrid1
						// 
						this.dataGrid1.DataMember = "";
						this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
						this.dataGrid1.Location = new System.Drawing.Point(24, 32);
						this.dataGrid1.Name = "dataGrid1";
						this.dataGrid1.Size = new System.Drawing.Size(224, 208);
						this.dataGrid1.TabIndex = 0;
						// 
						// Form1
						// 
						this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
						this.ClientSize = new System.Drawing.Size(292, 273);
						this.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.dataGrid1});
						this.Name = "Form1";
						this.Text = "Form1";
						this.Load += new System.EventHandler(this.Form1_Load);
						((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
						this.ResumeLayout(false);

					}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void Form1_Load(object sender, System.EventArgs e)
		{
			 DataSet ds = new DataSet();
          sqlDataAdapter1.Fill(ds);

          dataGrid1.DataSource = ds.DefaultViewManager;
		
		}
	}
}
		

