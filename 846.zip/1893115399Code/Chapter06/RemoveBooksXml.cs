using System;
using System.IO;
using System.Xml;

public class Sample
{
	public static void Main()
	{
		string filename = "C:\\books.xml";
		XmlDocument xmlDoc = new XmlDocument();
		xmlDoc.Load(filename);

		XmlNode root = xmlDoc.DocumentElement;
		Console.WriteLine("XML Document Fragment");
		Console.WriteLine("=====================");

		xmlDoc.Save(Console.Out);
		Console.WriteLine();
		Console.WriteLine("---------------------");


		Console.WriteLine("XML Document Fragment After RemoveAll");
		Console.WriteLine("=====================");
		//Remove all attribute and child nodes.
		root.RemoveAll();

		// Display the contents on the console after
		// removing elements and attributes
		xmlDoc.Save(Console.Out);


	}
}
