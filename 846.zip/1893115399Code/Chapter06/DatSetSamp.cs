using System;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Data.Common;
using System.Data;

class XmlWriterSamp
{
	static void Main(string[] args)
	{

		// Create a DataSet Object
		DataSet ds = new DataSet();
		// Fill with the data
		ds.ReadXml(@"c:\books.xml ");

 

	}


}

