using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{
        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.LoadXml("<Record> Some Value </Record>");
        
        XmlElement root = xmlDoc.DocumentElement;
        string str = root.ToString();

		XmlDocumentFragment xmlDocFragment = xmlDoc.CreateDocumentFragment();
		xmlDocFragment.InnerXml="<Fragment><SomeData>Fragment Data</SomeData></Fragment>";
        
		XmlElement rootNode = xmlDoc.DocumentElement;
   
		rootNode.ReplaceChild(xmlDocFragment, rootNode.LastChild);

        xmlDoc.Save(Console.Out);
	}		
 
}

