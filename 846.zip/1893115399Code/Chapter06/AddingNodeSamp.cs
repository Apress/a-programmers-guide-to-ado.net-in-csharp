using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{
		
        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.LoadXml("<Record> Some Value </Record>");

		// Adding a new comment node to the document
        XmlNode node1 = xmlDoc.CreateComment("DOM Testing Sample");
		xmlDoc.AppendChild( node1);

		// Adding an FirstName to the document
		node1 = xmlDoc.CreateElement("FirstName");
		node1.InnerText = "Mahesh";
		xmlDoc.DocumentElement.AppendChild(node1);

		xmlDoc.Save(Console.Out);

	}		
 
}

