using System;
using System.Xml.XPath;
using System.Xml;


namespace XmlPathNav
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		
		static void Main(string[] args)
        {
            // Load books.xml document
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(@"c:\books.xml");
        
            // Create XPathNavigator object by calling CreateNavigator of XmlDocument
            XPathNavigator nav = xmlDoc.CreateNavigator();

            // Look for author's first name
            Console.WriteLine("Author First Name");
            XPathNodeIterator itrator = nav.Select("descendant::first-name");         
            while( itrator.MoveNext() )
            {
                Console.WriteLine(itrator.Current.Value.ToString());
            }
    
        }

      
	}
}
