using System;
using System.Xml;

using System;
using System.Xml;

class XmlWriterSamp
{
    static void Main(string[] args)
    {
		XmlTextReader reader = new XmlTextReader(@"C:\books.xml");

		if (reader.Read())
		{
			Console.WriteLine(reader.Name);
			reader.MoveToContent(); 
			Console.WriteLine(reader.Name);
		}


    }

    }
