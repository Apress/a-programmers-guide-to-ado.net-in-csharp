using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Xml;

namespace XmlDataDocumentSamp
{
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;
		public Form1()
		{
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.Location = new System.Drawing.Point(8, 16);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(264, 232);
			this.dataGrid1.TabIndex = 0;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dataGrid1});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		
			// Create an XmlDataDocument object and read an XML
			XmlDataDocument xmlDatadoc = new XmlDataDocument();
            xmlDatadoc.DataSet.ReadXml("C:\\books.xml");

			// Create a DataSet object and fill it with the dataset 
			// of XmlDataDocument
			DataSet ds = new DataSet("Books DataSet");
			ds = xmlDatadoc.DataSet;

			// Attach data set view to the DataGrid control
            dataGrid1.DataSource = ds.DefaultViewManager; 
		}

		static void Main() 
		{
			Application.Run(new Form1());
		}
	}
}
