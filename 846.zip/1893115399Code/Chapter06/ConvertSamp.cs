using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{
		
		XmlTextWriter writer = new XmlTextWriter (@"c:\test.xml", null);
		
		
		writer.WriteStartElement("MyTestElements");
     
		bool bl = true;
		writer.WriteElementString("TestBoolean", XmlConvert.ToString(bl));
           
		DateTime vDate = new DateTime(2000, 01, 01 );
		writer.WriteElementString("TestDate", XmlConvert.ToString(vDate));
 
		writer.WriteEndElement();
 
		//Write the XML to file and close the writer
		writer.Flush();
		writer.Close();
	
	}		
 
}

