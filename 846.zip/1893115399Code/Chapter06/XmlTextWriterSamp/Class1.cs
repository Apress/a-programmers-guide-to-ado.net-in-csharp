using System;
using System.Xml;


class XmlWriterSamp
{
	static void Main(string[] args)
	{

		// Create a new file c:\xmlWriterTest.xml
		XmlTextWriter writer = new XmlTextWriter("C:\\xmlWriterTest.xml", null);

		// Opens the document 
		writer.WriteStartDocument();

		// Write comments
		writer.WriteComment("This program uses XmlTextWriter.");
		writer.WriteComment("Developed By: Mahesh Chand.");
		writer.WriteComment("================================");

		// Write first element
		writer.WriteStartElement("root");
		writer.WriteStartElement("r", "RECORD", "urn:record");

		// Write next element
		writer.WriteStartElement("FirstName","");
		writer.WriteString("Mahesh");
		writer.WriteEndElement();
        
		// Write one more element
		writer.WriteStartElement("LastName","");
		writer.WriteString("Chand");
		writer.WriteEndElement();

        
		// Create an XmlTextReader to read books.xml 
		XmlTextReader reader = new XmlTextReader(@"c:\books.xml");      
		while ( reader.Read() )
		{
			if(reader.NodeType == XmlNodeType.Element)          
			{
				// Add node.xml to xmlWriterTest.xml usign WriteNode
				writer.WriteNode(reader, true);                     
			}
		}

		// Ends the document.
		writer.WriteEndDocument();

		writer.Close();

		return;
	}
}


		