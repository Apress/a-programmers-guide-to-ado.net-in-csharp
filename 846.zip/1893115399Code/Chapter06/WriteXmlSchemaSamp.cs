using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{

		XmlDocument doc = new XmlDocument();
		doc.LoadXml("<book genre='programming'>" +
			"<title>ADO.NET Programming</title>" +
			"</book>");

		// Get the root node
		XmlNode root = doc.DocumentElement;

		//Create a new node.
		XmlElement newbook = doc.CreateElement("price");
		newbook.InnerText="44.95";

		//Add the node to the document.
		root.AppendChild(newbook);

		doc.Save(Console.Out);
	}
}

