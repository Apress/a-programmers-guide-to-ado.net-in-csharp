using System;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Data.Common;
using System.Data;

class XmlWriterSamp
{
	static void Main(string[] args)
	{
		// Create a data set object 
		DataSet ds = new DataSet("New DataSet");
      
		// Read xsl in an XmlTextReader
		XmlTextReader myXmlReader = new XmlTextReader(@"c:\books.xsl");

		// Call ReadXmlSchema	
		ds.ReadXmlSchema(myXmlReader);
	
		myXmlReader.Close();

		


	}


}

