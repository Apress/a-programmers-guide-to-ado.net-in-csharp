using System;
using System.Xml;

class XmlReaderSamp
{
	static void Main(string[] args)
	{
		XmlTextReader reader = new XmlTextReader(@"C:\books.xml");

		
		reader.MoveToContent();
		reader.MoveToFirstAttribute();
		Console.WriteLine("First Attribute Value" +reader.Value);
		Console.WriteLine("First Attribute Name" +reader.Name);

		while (reader.Read())
		{
			if (reader.HasAttributes)
			{
				Console.WriteLine(reader.Name + " Attribute");
				for (int i = 0; i < reader.AttributeCount; i++)
				{
					reader.MoveToAttribute(i);
					Console.WriteLine("Nam: "+reader.Name +", Value: "+ reader.Value);
				}
				reader.MoveToElement(); 
			}    
		}

	}
}
