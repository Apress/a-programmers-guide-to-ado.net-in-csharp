using System;
using System.IO;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;

class XmlTransformSamp
{
	public static void Main()
	{
		//Create a new XslTransform object and load the style sheet
        XslTransform xslt = new XslTransform();
        xslt.Load(@"c:\books.xsl");

        //Create a new XPathDocument and load the XML data to be transformed.
        XPathDocument mydata = new XPathDocument(@"c:\books.xml");

        //Create an XmlTextWriter which outputs to the console.
        XmlWriter writer = new XmlTextWriter(Console.Out);

        //Transform the data and send the output to the console.
        xslt.Transform(mydata, null, writer);
        
	}
}


