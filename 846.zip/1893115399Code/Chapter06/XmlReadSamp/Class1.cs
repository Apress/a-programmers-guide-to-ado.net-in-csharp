using System;
using System.Xml;

namespace XmlReadSamp
{
    class XmlReaderSamp
    {
        static void Main(string[] args)
        {
            int DecCounter=0, PICounter=0, DocCounter=0, CommentCounter=0, ElementCounter=0, AttributeCounter=0, TextCounter=0, WhitespaceCounter=0;

            // I'm using books.xml file. It comes with .NET Beta 2.
            // My books.xml is in C:\ root dir. Make sure your path is corrent. 
            //Create the XML fragment to be parsed.
            
            //XmlTextReader reader = new XmlTextReader(txtReader);
            XmlTextReader reader = new XmlTextReader(@"C:\books.xml");

            Console.WriteLine("General Information");
            Console.WriteLine("===================");
            Console.WriteLine(reader.Name);
            Console.WriteLine(reader.BaseURI);
            Console.WriteLine(reader.LocalName);

            while (reader.Read())
            {
                if (reader.HasValue)
                {                                       
                    Console.WriteLine("Name: "+reader.Name);
                    Console.WriteLine("Level of the node: " +reader.Depth.ToString());
                    Console.WriteLine("Value: "+reader.Value);
                }
                       
           
				Console.WriteLine("Node Type Information");
				Console.WriteLine("===================");            
           
                XmlNodeType type = reader.NodeType; 
                switch (type)
                {
                    case XmlNodeType.XmlDeclaration:
                        DecCounter++;
                        break;
                    case XmlNodeType.ProcessingInstruction:
                        PICounter++;
                        break;
                    case XmlNodeType.DocumentType:
                        DocCounter++;
                        break;
                    case XmlNodeType.Comment:
                        CommentCounter++;
                        break;
                    case XmlNodeType.Element:
                        ElementCounter++;
                        if (reader.HasAttributes)
                            AttributeCounter += reader.AttributeCount;
                        break;
                    case XmlNodeType.Text:
                        TextCounter++;
                        break;
                    case XmlNodeType.Whitespace:
                        WhitespaceCounter++;
                        break;
                }               
            }

            // Print the info
            Console.WriteLine("White Spaces:" +WhitespaceCounter.ToString());
            Console.WriteLine("Process Instructions:" +PICounter.ToString());
            Console.WriteLine("Declaration:" +DecCounter.ToString());
            Console.WriteLine("White Spaces:" +DocCounter.ToString());
            Console.WriteLine("Comments:" +CommentCounter.ToString());
            Console.WriteLine("Attributes:" +AttributeCounter.ToString());
            

        }
    }
}
