using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{

		XmlDocument doc = new XmlDocument();
		doc.LoadXml("<Record> Some Value </Record>");

		XmlNode root = doc.DocumentElement;
		doc.Save(Console.Out);

		//Remove all attribute and child nodes.
		root.RemoveAll();

		Console.WriteLine("Display the modified XML...");
		doc.Save(Console.Out);


	}
}

