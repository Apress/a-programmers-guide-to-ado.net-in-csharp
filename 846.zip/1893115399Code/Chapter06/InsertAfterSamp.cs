using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{
        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.Load(@"c:\\books.xml");
        
        XmlDocumentFragment xmlDocFragment = xmlDoc.CreateDocumentFragment();
        xmlDocFragment.InnerXml="<Fragment><SomeData>Fragment Data</SomeData></Fragment>";

        XmlNode aNode = xmlDoc.DocumentElement.FirstChild;
        aNode.InsertAfter(xmlDocFragment, aNode.LastChild);

        xmlDoc.Save(Console.Out);
    }       
 
}

