using System;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

namespace XPathNavigatorSamp
{
	class Class1
	{
		public void Main()
		{
			// Load books.xml document
			XmlDocument xmlDoc = new XmlDocument();
			xmlDoc.Load(@"c:\books.xml");
			// Create XPathNavigator object by calling CreateNavigator of XmlDocument
			XPathNavigator nav = xmlDoc.CreateNavigator();

			// Move to root node
			nav.MoveToRoot();
			string name = nav.Name;
			Console.WriteLine("Root node info: ");
			Console.WriteLine("Base URI" + nav.BaseURI.ToString());
			Console.WriteLine("Name: " +nav.Name.ToString());
			Console.WriteLine("Node Type: "+ nav.NodeType.ToString());
			Console.WriteLine("Node Value: "+nav.Value.ToString());
        
			if (nav.HasChildren)
			{
				nav.MoveToFirstChild();
				GetNodeInfo(nav);
			} 

			
		}
	}
}