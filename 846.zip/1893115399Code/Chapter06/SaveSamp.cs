using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{
		XmlDocument xmlDoc = new XmlDocument();
		xmlDoc.Load(@"C:\xmlWriterTest.xml");

		XmlTextWriter writer = new XmlTextWriter("C:\\domtest.xml", null);
		writer.Formatting = Formatting.Indented;
		xmlDoc.Save(writer);

		xmlDoc.Save(Console.Out);
	}       
   
}

