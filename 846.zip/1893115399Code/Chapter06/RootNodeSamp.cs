using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{
        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.LoadXml("<Record> Some Value </Record>");
        
        XmlElement root = xmlDoc.DocumentElement;
        string str = root.ToString();

		xmlDoc.RemoveAll();

		xmlDoc.Save(Console.Out);
	}		
 
}

