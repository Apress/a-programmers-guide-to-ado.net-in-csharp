using System;
using System.IO;
using System.Xml;

public class Sample
{
	public static void Main()
	{

		// Load a document fragment
		XmlDocument xmlDoc = new XmlDocument();
		xmlDoc.LoadXml("<book genre='programming'> <title>ADO.NET Programming</title> </book>");

		XmlNode root = xmlDoc.DocumentElement;
		Console.WriteLine("XML Document Fragment");
		Console.WriteLine("=====================");

		xmlDoc.Save(Console.Out);
		Console.WriteLine();
		Console.WriteLine("---------------------");


		Console.WriteLine("XML Document Fragment After RemoveAll");
		Console.WriteLine("=====================");
		//Remove all attribute and child nodes.
		root.RemoveAll();

		// Display the contents on the console after
		// removing elements and attributes
		xmlDoc.Save(Console.Out);

	}
}
