using System;
using System.Xml;

class XmlWriterSamp
{
	static void Main(string[] args)
	{
		
		// Open an XML file 
		string filename = @"C:\books.xml";     
		XmlDocument xmlDoc = new XmlDocument();		
		// xmlDoc.LoadXml(filename);

		xmlDoc.LoadXml("<Record> write something</Record>");

		/* 
		 * XmlDocument xmlDoc = new XmlDocument();
        string filename = @"C:\books.xml";        
        
        XmlTextReader reader = new XmlTextReader("C:\\books.xml");
        xmlDoc.Load(reader); */

        xmlDoc.Save(Console.Out);


	}		
 
}

