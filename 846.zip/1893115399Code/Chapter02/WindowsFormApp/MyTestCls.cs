using System;

namespace WindowsFormApp
{
	/// <summary>
	/// This is a test class
	/// </summary>
	public class MyTestCls : System.Windows.Forms.Form
	{
		public MyTestCls()
		{
			// 
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// The Name method
		/// </summary>
		public void MyTestMethod(int Name)
		{
		
		}

		/// <summary>
		/// This is a test property
		/// </summary>
		public int MyTestProperty
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}
	}
}
