using System;
using System.Windows.Forms;

namespace NotePadWindowsForms
{ 
	public class NotePadWindowsForms : System.Windows.Forms.Form
	{
		public NotePadWindowsForms()
		{
		}
		public static int Main()
		{
			Application.Run(new NotePadWindowsForms());
			return 0;
		}       
	}
}

