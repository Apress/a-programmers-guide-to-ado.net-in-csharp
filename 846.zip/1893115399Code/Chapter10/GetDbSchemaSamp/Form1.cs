using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace GetDbSchemaSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button BrowseBtn;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Button GetTablesBtn;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.Button GetSchemaBtn;

		private string dbName = "";
		private string curTableName = "";

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.BrowseBtn = new System.Windows.Forms.Button();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.GetTablesBtn = new System.Windows.Forms.Button();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.GetSchemaBtn = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 8);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(216, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "textBox1";
			// 
			// BrowseBtn
			// 
			this.BrowseBtn.Location = new System.Drawing.Point(248, 8);
			this.BrowseBtn.Name = "BrowseBtn";
			this.BrowseBtn.Size = new System.Drawing.Size(128, 24);
			this.BrowseBtn.TabIndex = 1;
			this.BrowseBtn.Text = "Browse Database";
			this.BrowseBtn.Click += new System.EventHandler(this.BrowseBtn_Click);
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 72);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(136, 264);
			this.listBox1.TabIndex = 2;
			// 
			// GetTablesBtn
			// 
			this.GetTablesBtn.Location = new System.Drawing.Point(16, 40);
			this.GetTablesBtn.Name = "GetTablesBtn";
			this.GetTablesBtn.Size = new System.Drawing.Size(112, 24);
			this.GetTablesBtn.TabIndex = 3;
			this.GetTablesBtn.Text = "Get Tables";
			this.GetTablesBtn.Click += new System.EventHandler(this.GetTablesBtn_Click);
			// 
			// listBox2
			// 
			this.listBox2.Location = new System.Drawing.Point(168, 96);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(296, 238);
			this.listBox2.TabIndex = 4;
			// 
			// GetSchemaBtn
			// 
			this.GetSchemaBtn.Location = new System.Drawing.Point(200, 48);
			this.GetSchemaBtn.Name = "GetSchemaBtn";
			this.GetSchemaBtn.Size = new System.Drawing.Size(136, 24);
			this.GetSchemaBtn.TabIndex = 5;
			this.GetSchemaBtn.Text = "Get Table Schema";
			this.GetSchemaBtn.Click += new System.EventHandler(this.GetSchemaBtn_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 349);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GetSchemaBtn,
																		  this.listBox2,
																		  this.GetTablesBtn,
																		  this.listBox1,
																		  this.BrowseBtn,
																		  this.textBox1});
			this.Name = "Form1";
			this.Text = "Database Schema Sample";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		
		private void BrowseBtn_Click(object sender, System.EventArgs e)
		{		
			OpenFileDialog fdlg = new OpenFileDialog(); 
			fdlg.Title = "C# Corner Open File Dialog" ; 
			fdlg.InitialDirectory = @"c:\" ; 
			fdlg.Filter = "All files (*.*)|*.mdb|MS-Access Database files (*.mdb)|*.mdb" ; 
			fdlg.FilterIndex = 2 ; 
			fdlg.RestoreDirectory = true ; 
			if(fdlg.ShowDialog() == DialogResult.OK) 
			{ 
				textBox1.Text = fdlg.FileName ; 
				dbName = fdlg.FileName;
			} 
		}

		private void GetTablesBtn_Click(object sender, System.EventArgs e)
		{

			// Connection string
			string strDSN = "Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source="+ dbName;
        
			try
			{
				// Create a connection and open it
				OleDbConnection conn = new OleDbConnection(strDSN);
				conn.Open();

				// Call GetOleDbSchemaTable to get the schema data table
				DataTable dt = conn.GetOleDbSchemaTable
					(OleDbSchemaGuid.Tables, new object[] 
					{null, null, null, "TABLE"});

				// Set DataSource and DisplayMember properties
				// of the list box control
				listBox1.DataSource = dt.DefaultView;   
				listBox1.DisplayMember = "TABLE_NAME";
        
				// Close the connection
				conn.Close();       
			}
			catch(Exception exp)
			{
				MessageBox.Show(exp.Message.ToString());
			}



		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void GetSchemaBtn_Click(object sender, System.EventArgs e)
		{
			// Get the selected item text of list box
			string selTable = listBox1.GetItemText(listBox1.SelectedItem);
            
			// Connection string
			string strDSN = "Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source="+ dbName;
        
			try
			{
				// Create and open connection
				OleDbConnection conn = new OleDbConnection(strDSN);
				conn.Open();

				string strSQL = "SELECT * FROM "+selTable;

				// Create data adapter
				OleDbDataAdapter myCmd = new OleDbDataAdapter
					(strSQL, conn );

            
				// Create and fill data set
				DataSet dtSet = new DataSet();
				myCmd.Fill( dtSet);
				DataTable dt = dtSet.Tables[0];
                
				// Add items to the list box control
				listBox2.Items.Add("Column Name, DataType, Unique,"+ 
					" AutoIncrement, AllowNull");
				listBox2.Items.Add("=====================================");

				foreach( DataColumn dc in dt.Columns )
				{
					listBox2.Items.Add(dc.ColumnName+" , "+dc.DataType +
						" ,"+dc.Unique +" ,"+dc.AutoIncrement+" ,"+dc.AllowDBNull );
				}
				// close connection
				conn.Close();
			}
			catch(Exception exp)
			{
				MessageBox.Show(exp.Message.ToString());
			}

		}
	}
}
