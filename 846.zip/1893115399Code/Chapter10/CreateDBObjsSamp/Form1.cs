using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace CreateDBObjsSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button CreateDBBtn;
		private System.Windows.Forms.Button CreateTableBtn;
		private System.Windows.Forms.Button CreateSPBtn;
		private System.Windows.Forms.Button CreateViewBtn;
		private System.Windows.Forms.Button ViewDataBtn;
		private System.Windows.Forms.Button ViewSPBtn;
		private System.Windows.Forms.Button ViewViewBtn;
		private System.Windows.Forms.DataGrid dataGrid1;


		private string ConnectionString ="Integrated Security=SSPI;" +
            "Initial Catalog=;" +
            "Data Source=localhost;";

        private SqlDataReader reader = null; 
        private SqlConnection conn = null; 
        private SqlCommand cmd = null;
        private System.Windows.Forms.Button AlterTableBtn;
        private string sql = null;
        private System.Windows.Forms.Button CreateOthersBtn;
		private System.Windows.Forms.Button DropTableBtn;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			AddInit();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			AppExit();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.CreateDBBtn = new System.Windows.Forms.Button();
			this.CreateTableBtn = new System.Windows.Forms.Button();
			this.CreateSPBtn = new System.Windows.Forms.Button();
			this.CreateViewBtn = new System.Windows.Forms.Button();
			this.ViewDataBtn = new System.Windows.Forms.Button();
			this.ViewSPBtn = new System.Windows.Forms.Button();
			this.ViewViewBtn = new System.Windows.Forms.Button();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.AlterTableBtn = new System.Windows.Forms.Button();
			this.CreateOthersBtn = new System.Windows.Forms.Button();
			this.DropTableBtn = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// CreateDBBtn
			// 
			this.CreateDBBtn.Location = new System.Drawing.Point(8, 8);
			this.CreateDBBtn.Name = "CreateDBBtn";
			this.CreateDBBtn.Size = new System.Drawing.Size(96, 32);
			this.CreateDBBtn.TabIndex = 0;
			this.CreateDBBtn.Text = "Create DB";
			this.CreateDBBtn.Click += new System.EventHandler(this.CreateDBBtn_Click);
			// 
			// CreateTableBtn
			// 
			this.CreateTableBtn.Location = new System.Drawing.Point(112, 8);
			this.CreateTableBtn.Name = "CreateTableBtn";
			this.CreateTableBtn.Size = new System.Drawing.Size(104, 32);
			this.CreateTableBtn.TabIndex = 1;
			this.CreateTableBtn.Text = "Create Table";
			this.CreateTableBtn.Click += new System.EventHandler(this.CreateTableBtn_Click);
			// 
			// CreateSPBtn
			// 
			this.CreateSPBtn.Location = new System.Drawing.Point(232, 8);
			this.CreateSPBtn.Name = "CreateSPBtn";
			this.CreateSPBtn.Size = new System.Drawing.Size(112, 32);
			this.CreateSPBtn.TabIndex = 2;
			this.CreateSPBtn.Text = "Create SP";
			this.CreateSPBtn.Click += new System.EventHandler(this.CreateSPBtn_Click);
			// 
			// CreateViewBtn
			// 
			this.CreateViewBtn.Location = new System.Drawing.Point(368, 8);
			this.CreateViewBtn.Name = "CreateViewBtn";
			this.CreateViewBtn.Size = new System.Drawing.Size(96, 32);
			this.CreateViewBtn.TabIndex = 3;
			this.CreateViewBtn.Text = "Create View";
			this.CreateViewBtn.Click += new System.EventHandler(this.CreateViewBtn_Click);
			// 
			// ViewDataBtn
			// 
			this.ViewDataBtn.Location = new System.Drawing.Point(16, 56);
			this.ViewDataBtn.Name = "ViewDataBtn";
			this.ViewDataBtn.Size = new System.Drawing.Size(104, 32);
			this.ViewDataBtn.TabIndex = 4;
			this.ViewDataBtn.Text = "View Data";
			this.ViewDataBtn.Click += new System.EventHandler(this.ViewDataBtn_Click);
			// 
			// ViewSPBtn
			// 
			this.ViewSPBtn.Location = new System.Drawing.Point(136, 56);
			this.ViewSPBtn.Name = "ViewSPBtn";
			this.ViewSPBtn.Size = new System.Drawing.Size(88, 32);
			this.ViewSPBtn.TabIndex = 5;
			this.ViewSPBtn.Text = "View SP";
			this.ViewSPBtn.Click += new System.EventHandler(this.ViewSPBtn_Click);
			// 
			// ViewViewBtn
			// 
			this.ViewViewBtn.Location = new System.Drawing.Point(256, 56);
			this.ViewViewBtn.Name = "ViewViewBtn";
			this.ViewViewBtn.Size = new System.Drawing.Size(120, 32);
			this.ViewViewBtn.TabIndex = 6;
			this.ViewViewBtn.Text = "View View";
			this.ViewViewBtn.Click += new System.EventHandler(this.ViewViewBtn_Click);
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(24, 120);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(368, 280);
			this.dataGrid1.TabIndex = 7;
			// 
			// AlterTableBtn
			// 
			this.AlterTableBtn.Location = new System.Drawing.Point(488, 8);
			this.AlterTableBtn.Name = "AlterTableBtn";
			this.AlterTableBtn.Size = new System.Drawing.Size(104, 32);
			this.AlterTableBtn.TabIndex = 8;
			this.AlterTableBtn.Text = "Alter Table";
			this.AlterTableBtn.Click += new System.EventHandler(this.AlterTableBtn_Click);
			// 
			// CreateOthersBtn
			// 
			this.CreateOthersBtn.Location = new System.Drawing.Point(448, 104);
			this.CreateOthersBtn.Name = "CreateOthersBtn";
			this.CreateOthersBtn.Size = new System.Drawing.Size(136, 40);
			this.CreateOthersBtn.TabIndex = 9;
			this.CreateOthersBtn.Text = "Create Others";
			this.CreateOthersBtn.Click += new System.EventHandler(this.CreateOthersBtn_Click);
			// 
			// DropTableBtn
			// 
			this.DropTableBtn.Location = new System.Drawing.Point(448, 160);
			this.DropTableBtn.Name = "DropTableBtn";
			this.DropTableBtn.Size = new System.Drawing.Size(136, 40);
			this.DropTableBtn.TabIndex = 10;
			this.DropTableBtn.Text = "Drop Table";
			this.DropTableBtn.Click += new System.EventHandler(this.DropTableBtn_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(608, 413);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.DropTableBtn,
																		  this.CreateOthersBtn,
																		  this.AlterTableBtn,
																		  this.dataGrid1,
																		  this.ViewViewBtn,
																		  this.ViewSPBtn,
																		  this.ViewDataBtn,
																		  this.CreateViewBtn,
																		  this.CreateSPBtn,
																		  this.CreateTableBtn,
																		  this.CreateDBBtn});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Called when application starts. 
		// Initializes all variables, opens connection etc
		private void AddInit()
		{
			
		}

		// Called when you are done with the applicaton
		// Or from Close button
		private void AppExit()
		{
			if (reader != null)
				reader.Close();
			if (conn.State == ConnectionState.Open)
				conn.Close();
		}

		// This method creates a new SQL Server database
        private void CreateDBBtn_Click(object sender, System.EventArgs e)
        {     
			
			try
			{
				// Create a connection
				conn = new SqlConnection(ConnectionString);

				// Open the connection
				if( conn.State != ConnectionState.Open)
					conn.Open();

				string sql = "CREATE DATABASE mydb ON PRIMARY"
					+"(Name=test_data, filename = 'C:\\mysql\\mydb_data.mdf', size=3,"
					+"maxsize=5, filegrowth=10%)log on"
					+"(name=mydbb_log, filename='C:\\mysql\\mydb_log.ldf',size=3,"
					+"maxsize=20,filegrowth=1)" ;

				ExecuteSQLStmt(sql);
			}
			catch(Exception exp)
			{
				MessageBox.Show(exp.Message);
			}
        }

		private void CreateTableBtn_Click(object sender, System.EventArgs e)
        {
            // Open the connection
            if( conn.State == ConnectionState.Open)
                conn.Close();

            ConnectionString ="Integrated Security=SSPI;" +
            "Initial Catalog=mydb;" +
            "Data Source=localhost;";
        
            conn.ConnectionString = ConnectionString;
            conn.Open();

			// The Create table statement creates a new myTable table
			// Columns myId, myName, myAddress, and myBalance

            sql = "CREATE TABLE myTable"+
                "(myId INTEGER CONSTRAINT PKeyMyId PRIMARY KEY,"+
                "myName CHAR(50), myAddress CHAR(255), myBalance FLOAT)" ;

            cmd = new SqlCommand(sql, conn);

            try
            {
                cmd.ExecuteNonQuery();      
            
                // Adding records the table
                sql = "INSERT INTO myTable(myId, myName, myAddress, myBalance) "+
                    "VALUES (1001, 'Puneet Nehra', 'A 449 Sect 19, DELHI', 23.98 ) " ;
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();  

                sql = "INSERT INTO myTable(myId, myName, myAddress, myBalance) "+
                    "VALUES (1002, 'Anoop Singh', 'Lodi Road, DELHI', 353.64) " ;
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();  


                sql = "INSERT INTO myTable(myId, myName, myAddress, myBalance) "+
                    "VALUES (1003, 'Rakesh M', 'Nag Chowk, Jabalpur M.P.', 43.43) " ;
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();  

                sql = "INSERT INTO myTable(myId, myName, myAddress, myBalance) "+
                    "VALUES (1004, 'Madan Kesh', '4th Street, Lane 3, DELHI', 23.00) " ;
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();  

            }
            catch(SqlException exp)
            {
                MessageBox.Show(exp.Message.ToString());
            }
        }


		
		private void ExecuteSQLStmt(string sql)
		{
			// Open the connection
			if( conn.State == ConnectionState.Open)
				conn.Close();

			
			ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=mydb;" +
				"Data Source=localhost;";

			/*ConnectionString = "Initial Catalog=mydb;"+
				"Data Source=localhost;Uid=sa;Pwd=";*/

		
			conn.ConnectionString = ConnectionString;
			conn.Open();

			cmd = new SqlCommand(sql, conn);
			try
			{
				cmd.ExecuteNonQuery();
			}
			catch(SqlException exp)
			{
				MessageBox.Show(exp.Message.ToString());
			}
		}

		private void CreateSPBtn_Click(object sender, System.EventArgs e)
		{
			sql = "CREATE PROCEDURE myProc AS"+
				" SELECT myName, myAddress FROM myTable GO";
			ExecuteSQLStmt(sql);			
		}

		private void CreateViewBtn_Click(object sender, System.EventArgs e)
		{
			sql = "CREATE VIEW myView AS SELECT myName FROM myTable"; 
			ExecuteSQLStmt(sql);	
		}

		
		private void AlterTableBtn_Click(object sender, System.EventArgs e)
		{
			sql = "ALTER TABLE MyTable ALTER COLUMN"+
				"myName CHAR(100) NOT NULL";						
			ExecuteSQLStmt(sql);		
		}

		private void CreateOthersBtn_Click(object sender, System.EventArgs e)
		{
			sql = "CREATE UNIQUE CLUSTERED INDEX "+
				"myIdx ON myTable(myName)";		
			ExecuteSQLStmt(sql);	

			sql = "CREATE RULE myRule "+
				"AS @myBalance >= 32 AND @myBalance < 60";
			ExecuteSQLStmt(sql);		
		}

		private void DropTableBtn_Click(object sender, System.EventArgs e)
		{
			string sql = "DROP TABLE MyTable";  
			ExecuteSQLStmt(sql);	
		}

		private void ViewDataBtn_Click(object sender, System.EventArgs e)
		{
			/// Open the connection
			if( conn.State == ConnectionState.Open)
				conn.Close();

			ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=mydb;" +
				"Data Source=localhost;";
		
			try
			{
				conn.ConnectionString = ConnectionString;
				conn.Open();	
		
				// Create a data adapter
				SqlDataAdapter da = new SqlDataAdapter
					("SELECT * FROM myTable", conn);

				// Create DataSet, fill it and view in data grid
				DataSet ds = new DataSet("myTable");
				da.Fill(ds, "myTable");
				dataGrid1.DataSource = ds.Tables["myTable"].DefaultView;
			}
			catch(Exception exp)
			{
				MessageBox.Show(exp.Message.ToString());
			}
		}

		private void ViewSPBtn_Click(object sender, System.EventArgs e)
		{
			
			/// Open the connection
			if( conn.State == ConnectionState.Open)
				conn.Close();

			ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=mydb;" +
				"Data Source=localhost;";
		
			try
			{

				conn.ConnectionString = ConnectionString;
				conn.Open();	
	
				// Create a data adapter
				SqlDataAdapter da = new SqlDataAdapter("myProc", conn);

				// Create DataSet, fill it and view in data grid
				DataSet ds = new DataSet("SP");
				da.Fill(ds, "SP");
				dataGrid1.DataSource = ds.DefaultViewManager;		
			}
			catch(Exception exp)
			{
				MessageBox.Show(exp.Message.ToString());
			}
		}

		private void ViewViewBtn_Click(object sender, System.EventArgs e)
		{

			/// Open the connection
			if( conn.State == ConnectionState.Open)
				conn.Close();

			ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=mydb;" +
				"Data Source=localhost;";
		
			try
			{
				conn.ConnectionString = ConnectionString;
				conn.Open();	
	
				// Create a data adapter
				SqlDataAdapter da = new SqlDataAdapter
					("SELECT * FROM myView", conn);

				// Create DataSet, fill it and view in data grid
				DataSet ds = new DataSet();
				da.Fill(ds);
				dataGrid1.DataSource = ds.DefaultViewManager;	
			}
			catch(Exception exp)
			{
				MessageBox.Show(exp.Message.ToString());
			}
		}		
	}
}


