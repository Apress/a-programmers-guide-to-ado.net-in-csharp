using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;


namespace StoredProcOutputParameter
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			string connString = 
                "Data Source=localhost;Integrated Security=SSPI;"
                + "Initial Catalog=northwind";
            string sql = 
            "SELECT CategoryID, CategoryName, Description FROM Categories";

            SqlConnection conn = new SqlConnection(connString);
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);

            da.InsertCommand = new SqlCommand("AddCat1", conn);
            da.InsertCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter myParm = 
                da.InsertCommand.Parameters.Add("@RowCount", SqlDbType.Int);
            myParm.Direction = ParameterDirection.ReturnValue;

            da.InsertCommand.Parameters.Add
                ("@CategoryName", SqlDbType.NChar, 15, "CategoryName");
            da.InsertCommand.Parameters.Add
                ("@Description", SqlDbType.Char, 16, "Description");
            myParm = da.InsertCommand.Parameters.Add
                ("@Identity", SqlDbType.Int, 0, "CategoryID");
            myParm.Direction = ParameterDirection.Output;

            DataSet ds = new DataSet();
            da.Fill(ds, "Categories");

            DataRow row = ds.Tables["Categories"].NewRow();
            row["CategoryName"] = "Beverages";
            row["Description"] = "Chai";
            ds.Tables["Categories"].Rows.Add(row);

            da.Update(ds, "Categories");

            Console.WriteLine( 
                da.InsertCommand.Parameters["@RowCount"].Value.ToString() );
		}
	}
}
