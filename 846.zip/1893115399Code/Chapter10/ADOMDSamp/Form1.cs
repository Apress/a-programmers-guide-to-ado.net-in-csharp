using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ADOMD;
using ADODB;

namespace ADOMDSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ListBox listBox2;

		// Define varialbes
        private string strConn; 
        private Connection dbConn; 
        private Catalog dtCatalog; 
        private CubeDefs cubes;
		private System.Windows.Forms.Button button2; 



		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.button1 = new System.Windows.Forms.Button();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(104, 8);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(88, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "textBox1";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 24);
			this.label1.TabIndex = 1;
			this.label1.Text = "Number of Cubes:";
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(16, 56);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(144, 199);
			this.listBox1.TabIndex = 2;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(192, 24);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(112, 32);
			this.button1.TabIndex = 3;
			this.button1.Text = "Get Dimensions";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// listBox2
			// 
			this.listBox2.Location = new System.Drawing.Point(200, 72);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(160, 212);
			this.listBox2.TabIndex = 4;
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(312, 24);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(144, 32);
			this.button2.TabIndex = 5;
			this.button2.Text = "Get Dimension Members";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(464, 374);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button2,
																		  this.listBox2,
																		  this.button1,
																		  this.listBox1,
																		  this.label1,
																		  this.textBox1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
        {
            strConn = "Provider=msolap; Data Source = GL61LS;" +
                "Initial Catalog = FoodMart 2000; User ID =sa; Pwd=";

            // Create and open a connection
            dbConn = new Connection ();
            dbConn.Open (strConn, "", "", 
                (int)ConnectModeEnum.adModeUnknown);

            // Create a Catalog object and set it's active connection 
            // as connection
            dtCatalog = new Catalog ();
            dtCatalog.ActiveConnection = (object)dbConn;

            // Get all cubes
            cubes = dtCatalog.CubeDefs;
            // Set text box text as total number of cubes
            textBox1.Text = cubes.Count.ToString();

            foreach (CubeDef cube in cubes)
            {
                string str = "";
                listBox1.Items.Add(cube.Name.ToString());

                str = "Cube Name :"+ cube.Name.ToString() + ", ";
                str += "Description :"+ cube.Description.ToString() + ", ";
                str += "Dimensions :"+ cube.Dimensions.ToString();              
            }

            listBox1.SetSelected(0, true);
        
        }

        private void button1_Click(object sender, System.EventArgs e)
        {       

            // Get the selected cube
            CubeDef cube = cubes[listBox1.SelectedItem.ToString()];
            
            // Get all the dimensions of the selecte cube
            for (int i=0; i< cube.Dimensions.Count; i++)
            {
                Dimension dim = cube.Dimensions[i];
                listBox2.Items.Add(dim.Name.ToString());                
            }
            listBox2.SetSelected(0, true);
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            // Get the selected cube
            CubeDef cube = cubes[listBox1.SelectedItem.ToString()];
            // Get the selected Dimension
            Dimension dim = cube.Dimensions[listBox2.SelectedItem.ToString()];

            MessageBox.Show("Dimension Properties :: Name="+dim.Name.ToString()
                +", Description="+ dim.Description.ToString() +", Hierarchies="
                + dim.Hierarchies.ToString() +", Unique Name="
                + dim.UniqueName.ToString());           
        }

		
	}
}
