using System;
using System.Data;
using System.Data.SqlClient;

namespace MySPStoredProcedureSamp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// Create a Connection Object
			string ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=Northwind;" +
				"Data Source=G61LS;";

			SqlConnection conn = new SqlConnection(ConnectionString);
			
            
			conn.Open();

			SqlCommand cmd = new SqlCommand("mySP", conn);
			cmd.CommandType = CommandType.StoredProcedure;
            
			SqlDataReader reader = cmd.ExecuteReader();

			string orderlist = "";
			while (reader.Read())
			{
				Console.Write(reader[0].ToString());
				Console.Write(reader[1].ToString());
				Console.WriteLine(reader[2].ToString());
			}
        
			Console.Read();

			// Close reader and connection
			reader.Close();
			conn.Close(); }

	}
}
