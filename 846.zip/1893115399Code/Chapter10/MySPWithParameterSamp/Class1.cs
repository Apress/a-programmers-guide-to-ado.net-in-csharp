using System;
using System.Data;
using System.Data.SqlClient;

namespace MySPWithParameterSamp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// Create a Connection Object
			string ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=Northwind;" +
				"Data Source=G61LS;";
			SqlConnection conn = new SqlConnection(ConnectionString);

			SqlCommand StoredProcedureCommand = new SqlCommand("mySP", conn);
			StoredProcedureCommand.CommandType = CommandType.StoredProcedure;

			SqlParameter param = new SqlParameter();
			param = StoredProcedureCommand.Parameters.Add
				("@country", SqlDbType.VarChar, 50);
			param.Direction = ParameterDirection.Input;
			param.Value = "UK";
            
			conn.Open();
			SqlDataReader reader = StoredProcedureCommand.ExecuteReader();
            
			while (reader.Read())
			{
				Console.Write(reader[0].ToString());
				Console.Write(reader[1].ToString());
				Console.WriteLine(reader[2].ToString());
			}
        
			Console.Read();

			// Close reader and connection
			reader.Close();
			conn.Close();

		}
	}
}
