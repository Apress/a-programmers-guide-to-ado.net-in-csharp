using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;


namespace DataBoundControlsSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.TextBox textBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.listBox1 = new System.Windows.Forms.ListBox();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(344, 160);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(128, 20);
			this.textBox1.TabIndex = 3;
			this.textBox1.Text = "textBox1";
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.Location = new System.Drawing.Point(8, 24);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(192, 232);
			this.dataGrid1.TabIndex = 0;
			// 
			// comboBox1
			// 
			this.comboBox1.DropDownWidth = 128;
			this.comboBox1.Location = new System.Drawing.Point(344, 40);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(128, 21);
			this.comboBox1.TabIndex = 2;
			this.comboBox1.Text = "comboBox1";
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(216, 32);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(104, 212);
			this.listBox1.TabIndex = 1;
			this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(480, 277);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.textBox1,
																		  this.comboBox1,
																		  this.listBox1,
																		  this.dataGrid1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void FillDataGrid()
		{
			// Create a Connection Object
			string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=c:\Northwind.mdb";
			OleDbConnection conn = new OleDbConnection(ConnectionString);
			string SQL = "SELECT * FROM Customers";

			// Open the connection
			conn.Open();

			//Create a DataAdapter object
			OleDbDataAdapter adapter = new OleDbDataAdapter(SQL, conn);

			DataSet ds = new DataSet("Customers");
			adapter.Fill(ds, "Customers");

			dataGrid1.DataSource = ds.DefaultViewManager;

			// Close the connection
			conn.Close();		
		}

		private void FillListBox()
		{
			// Create a Connection Object
			string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=c:\Northwind.mdb";
			OleDbConnection conn = new OleDbConnection(ConnectionString);
			string SQL = "SELECT * FROM Customers";

			// Open the connection
			conn.Open();

			//Create a DataAdapter object
			OleDbDataAdapter adapter = new OleDbDataAdapter(SQL, conn);

			DataSet ds = new DataSet("Customers");
			adapter.Fill(ds, "Customers");

			listBox1.DataSource = ds.DefaultViewManager;
			listBox1.DisplayMember = "CustomerID";


			// Close the connection
			conn.Close();		
		}

		private void FillComboBox()
		{
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			FillListBox();
			FillDataGrid();
		}

		private void listBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{

		}

	}
}
