using System;
using System.Data;
using System.Data.SqlClient;

namespace TestApp1
{
	class Class1
	{
		static void Main(string[] args)
		{
			// Connection and SQL strings
			string SQL = "SELECT * FROM Orders";

			// Create a Connection Object
			string ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=Northwind;" +
				"Data Source=localhost;";
			SqlConnection conn = new SqlConnection(ConnectionString);

			// Create a SqlCommand with stored procedure as string
			SqlCommand cmd = 
				new SqlCommand("Sales By Year", conn);
			// set Command's CommandType as StoredProcedure
			cmd.CommandType = CommandType.StoredProcedure;

			// Create a SqlParameter and add a parameter
			SqlParameter parm1 = cmd.Parameters.Add
				("@Beginning_Date", SqlDbType.DateTime, 20); 
			parm1.Value = "7/1/1996";
			SqlParameter parm2 = cmd.Parameters.Add
				("@Ending_Date", SqlDbType.DateTime, 20); 
			parm2.Value = "7/31/1996";

			// Open the connection
			conn.Open();

			// Call ExecuteReader to execute the stored procedure
			SqlDataReader reader 
				= cmd.ExecuteReader();
			string orderlist = "";

			// Read data from the reader
			while (reader.Read())
			{
				string result = reader["OrderID"].ToString();
				orderlist += result + '\n';
			}
        
			// close the connection and reader
			reader.Close();
			conn.Close();
            
			// Print data on the console
			Console.WriteLine("Orders in July");
			Console.WriteLine("===============");
			Console.WriteLine(orderlist);
		
		}
	}
}
