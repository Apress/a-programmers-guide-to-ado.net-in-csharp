using System;
using System.Data;
using System.Data.OleDb;

namespace OleDbCommandSamp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// Connection and SQL strings
			string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source=c:\\Northwind.mdb";
			string SQL = "SELECT * FROM Orders";

			// Create connection object
			OleDbConnection conn = new OleDbConnection(ConnectionString);
			// Create command object
			OleDbCommand cmd = new OleDbCommand(SQL);
			cmd.Connection = conn;
    
			// Open connection
			conn.Open();
			// Call command's ExecuteReader
			OleDbDataReader reader = cmd.ExecuteReader();

			while (reader.Read()) 
			{
				Console.Write("OrderID:"+reader.GetInt32(0).ToString() );
				Console.Write(" ,");
				Console.WriteLine("Customer:" + reader.GetString(1).ToString() );
			}
			// close reader and connection
			reader.Close();
			conn.Close();

		}
	}
}
