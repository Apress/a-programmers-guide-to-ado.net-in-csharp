using System;
using System.Data;
using System.Data.SqlClient;

namespace SqlCommandSamp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// Connection and SQL strings
			string SQL = "SELECT * FROM Orders";
			// Create a Connection Object
			string ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=Northwind;" +
				"Data Source=localhost;";
			SqlConnection conn = new SqlConnection(ConnectionString);


			// Create command object
			SqlCommand cmd = new SqlCommand(SQL, conn);

    
			// Open connection
			conn.Open();
			// Call command's ExecuteReader
			SqlDataReader reader = cmd.ExecuteReader();
			try 
			{
				while (reader.Read()) 
				{
					Console.Write("OrderID:"+reader.GetInt32(0).ToString() );
					Console.Write(" ,");
					Console.WriteLine("Customer:" + reader.GetString(1).ToString() );
				}
			}
			finally 
			{
				// close reader and connection
				reader.Close();
				conn.Close();
			}   

		}
	}
}
