using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace ConcurrenctySampTest
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(32, 24);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(184, 24);
			this.button1.TabIndex = 0;
			this.button1.Text = "Optimistic Concurrencty";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(24, 104);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(192, 24);
			this.button2.TabIndex = 1;
			this.button2.Text = "Passimistic Concurrency";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button2,
																		  this.button1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		
void TestOptimisticConcurrency()
{
    try
    {
    string ConnectionString ="Integrated Security=SSPI;" +
        "Initial Catalog=Northwind;" +
        "Data Source=localhost;";
    SqlConnection conn = new SqlConnection(ConnectionString);
    conn.Open();
    SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", conn);
    DataSet ds = new DataSet("test");
    SqlCommand updateCmd = new SqlCommand();
    updateCmd.CommandText = @"UPDATE Orders SET CustomerID = @CustomerID,"+
    "OrderDate = @OrderDate, ShippedDate = @ShippedDate WHERE "+
    "(OrderID = @Original_OrderID) AND (CustomerID = @Original_CustomerID "+
    "OR @Original_CustomerID IS NULL AND CustomerID IS NULL) AND "+
    "(OrderDate = @Original_OrderDate OR @Original_OrderDate "+
    "IS NULL AND OrderDate IS NULL) AND (ShippedDate = "+
    "@Original_ShippedDate OR @Original_ShippedDate IS NULL AND "+
    "ShippedDate IS NULL); SELECT CustomerID, OrderDate, ShippedDate, "+
    "OrderID FROM Orders WHERE (OrderID = @OrderID)";

    updateCmd.Connection = conn;
    // CustomerID parameter
    updateCmd.Parameters.Add(new SqlParameter
        ("@CustomerID", SqlDbType.NVarChar, 5, "CustomerID"));      
    // OrderDate parameter
    updateCmd.Parameters.Add(new SqlParameter
        ("@OrderDate", SqlDbType.DateTime, 8, "OrderDate"));
    // ShippedDate parameter
    updateCmd.Parameters.Add(new SqlParameter
        ("@ShippedDate", SqlDbType.DateTime, 8, "ShippedDate"));
    updateCmd.Parameters.Add(new SqlParameter
        ("@Original_OrderID", SqlDbType.Int, 4, 
        ParameterDirection.Input, false, 
        ((System.Byte)(0)), ((System.Byte)(0)),
        "OrderID", DataRowVersion.Original, null));
    updateCmd.Parameters.Add(new SqlParameter
        ("@Original_CustomerID", SqlDbType.NVarChar, 
        5, ParameterDirection.Input, false, ((System.Byte)(0)), 
        ((System.Byte)(0)), "CustomerID", 
        DataRowVersion.Original, null));
        updateCmd.Parameters.Add(new SqlParameter
        ("@Original_OrderDate", SqlDbType.DateTime, 
        8, ParameterDirection.Input, false, ((System.Byte)(0)), 
        ((System.Byte)(0)), "OrderDate", 
        DataRowVersion.Original, null));
    updateCmd.Parameters.Add(new SqlParameter
        ("@Original_ShippedDate", SqlDbType.DateTime, 
        8, ParameterDirection.Input, false, ((System.Byte)(0)), 
        ((System.Byte)(0)), "ShippedDate", 
        DataRowVersion.Original, null));
    updateCmd.Parameters.Add
        (new SqlParameter("@OrderID", SqlDbType.Int, 
        4, "OrderID"));

		da.UpdateCommand = updateCmd;
		da.Fill(ds, "Orders");
		// update the row in the dataset
		ds.Tables["Orders"].Rows[0].BeginEdit();
		ds.Tables["Orders"].Rows[0]["OrderDate"] = DateTime.Now;
		ds.Tables["Orders"].Rows[0]["ShipCity"] = "Leone";		
		ds.Tables["Orders"].Rows[0].EndEdit();
		// update the row in the data Source (Orders Table)
		da.Update(ds, "Orders");
		MessageBox.Show("Finished updating first row.");
		// close connection
		conn.Close();

    }
    catch(SqlException ex)
    {
        MessageBox.Show(ex.Message.ToString());
    }
}

void TestPessimisticConcurrency()
{
try
{
    // Create a Connection Object
    string ConnectionString ="Integrated Security=SSPI;" +
        "Initial Catalog=Northwind;" +
        "Data Source=localhost;";
    SqlConnection conn = new SqlConnection(ConnectionString);
    conn.Open();
    // Create a transaction that locks the records of the query
    SqlTransaction tr = conn.BeginTransaction
        (IsolationLevel.RepeatableRead, "test");
    // Create a command that updates the order of 
    // the database using the transaction

    SqlCommand cmd = new SqlCommand("UPDATE Orders SET "+
        "ShippedDate = '5/10/01', ShipCity = 'Columbus' WHERE "+
        "OrderID = 10248",   conn,  tr); 

    // Execute the update
    cmd.ExecuteNonQuery();
                        
    // Generate message
    MessageBox.Show("Wait for keypress...");

    tr.Commit(); // transaction is committed
    conn.Close();
}
catch(SqlException ex)
{
    MessageBox.Show(ex.Message.ToString());
}
}

private void button1_Click(object sender, System.EventArgs e)
{
	TestOptimisticConcurrency();
}

private void button2_Click(object sender, System.EventArgs e)
{
	TestPessimisticConcurrency();
}
}
}

