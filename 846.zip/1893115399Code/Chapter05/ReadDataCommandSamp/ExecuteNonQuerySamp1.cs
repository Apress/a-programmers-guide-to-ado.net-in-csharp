using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace ReadDataCommandSamp
{
	class Class1
	{
		static void Main(string[] args)
        {
            // Create a Connection Object
            string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=c:\Northwind.mdb";
            OleDbConnection conn = new OleDbConnection(ConnectionString);
  
			// open an existing Connection to the Database and Create a 
			// Command Object with it:

			conn.Open();
			OleDbCommand cmd = new OleDbCommand("Customers", conn);


			// Assign the SQL Insert statement we want to execute to the CommandText
			//cmd.CommandText = @"INSERT INTO Customers(Address, City, CompanyName, ContactName, 
             //   CustomerID) VALUES ('111 Broad St.', 'NY', 'Xerox', 'Fred Biggles', 1400)";
			
			cmd.CommandText = @"DELETE * FROM Customers WHERE CustomerID = 1400)";


			// Call ExecuteNonQuery on the Command Object to execute insert
			cmd.ExecuteNonQuery();
			        
            // release objects
            conn.Close();                  
          
        }
    }


}
