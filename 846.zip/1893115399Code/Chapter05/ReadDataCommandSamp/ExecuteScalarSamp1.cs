using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace ReadDataCommandSamp
{
	class Class1
	{
        static void Main(string[] args)
        {
            // Create a Connection Object
            string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=c:\Northwind.mdb";
            OleDbConnection conn = new OleDbConnection(ConnectionString);
  
            // Creating a command object
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = "SELECT Count(*) FROM Customers";
            cmd.Connection = conn;

            int counter = (int)cmd.ExecuteScalar();
            
            Console.WriteLine("Total rows returned are :" + counter.ToString());
                   
            // release objects
            conn.Close();                  
          
        }
    }


}
