using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace ReadDataCommandSamp
{
	class Class1
	{
		static void Main(string[] args)
        {
            // Connection and SQL strings
            string SQL = "SELECT * FROM Orders";

            // Create a Connection Object
            string ConnectionString ="Integrated Security=SSPI;" +
                "Initial Catalog=Northwind;" +
                "Data Source=localhost;";
            SqlConnection conn = new SqlConnection(ConnectionString);

  
            SqlCommand StoredProcedureCommand = new SqlCommand("Sales By Year", conn);
            StoredProcedureCommand.CommandType = CommandType.StoredProcedure;
            SqlParameter myParm1 = StoredProcedureCommand.Parameters.Add( "@Beginning_Date", SqlDbType.DateTime, 20); 
            myParm1.Value = "7/1/1996";
            SqlParameter myParm2 = StoredProcedureCommand.Parameters.Add("@Ending_Date", SqlDbType.DateTime, 20); 
            myParm2.Value = "7/31/1996";
            conn.Open();
            SqlDataReader TheReader = StoredProcedureCommand.ExecuteReader();
            string orderlist = "";
            while (TheReader.Read())
            {
               // string result = TheReader["OrderID"].ToString();
                //orderlist += result + '\n';

				string nextID = TheReader["OrderID"].ToString();
				string nextSubtotal = TheReader["Subtotal"].ToString();
				orderlist += nextID + '\t' + nextSubtotal + '\n';

            }
        
            conn.Close();
            
            Console.WriteLine("Orders in July");
            Console.WriteLine("===============");
            Console.WriteLine(orderlist);
        }
    }


}
