using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.Common;


namespace DataRowSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			CreateCustomersTable();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.Location = new System.Drawing.Point(8, 8);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(416, 296);
			this.dataGrid1.TabIndex = 0;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(432, 309);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dataGrid1});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		// This method creates Customers table		
		private void CreateCustomersTable()
		{
			// Create a new DataTable.
			System.Data.DataTable custTable = new DataTable("Customers");
			DataColumn dtColumn;
			
			// Create id Column
			dtColumn = new DataColumn();
			dtColumn.DataType = System.Type.GetType("System.Int32");
			dtColumn.ColumnName = "id";
			dtColumn.Caption = "Cust ID";
			dtColumn.ReadOnly = true;
			dtColumn.Unique = true;
			// Add id Column to the DataColumnCollection.
			custTable.Columns.Add(dtColumn);
 
			// Create Name column.
			dtColumn = new DataColumn();
			dtColumn.DataType = System.Type.GetType("System.String");
			dtColumn.ColumnName = "Name";
			dtColumn.Caption = "Cust Name";
			dtColumn.AutoIncrement = false;
			dtColumn.ReadOnly = false;
			dtColumn.Unique = false;
			// Add Name column to the table.
			custTable.Columns.Add(dtColumn);


			// Create Address column.
			dtColumn = new DataColumn();
			dtColumn.DataType = System.Type.GetType("System.String");
			dtColumn.ColumnName = "Address";
			dtColumn.Caption = "Address";
			dtColumn.ReadOnly = false;
			dtColumn.Unique = false;
			// Add Address column to the table.
			custTable.Columns.Add(dtColumn);
 
			// Make the ID column the primary key column.
			DataColumn[] PrimaryKeyColumns = new DataColumn[1];
			PrimaryKeyColumns[0] = custTable.Columns["id"];
			custTable.PrimaryKey = PrimaryKeyColumns;
 
			// Instantiate the DataSet variable.
			DataSet ds = new DataSet("Customers");
			// Add the custTable to the DataSet.
			ds.Tables.Add(custTable);
 
			// Add rows to the custTable using its NewRow method
			// I add three customers with thier addresses, name and id
			DataRow row1 = custTable.NewRow();
			row1["id"] = 1001;
			row1["Address"] = "43 Lanewood Road, Cito, CA";
			row1["Name"] = "George Bishop ";
			custTable.Rows.Add(row1);

			DataRow row2 = custTable.NewRow();
			row2["id"] = 1002;
			row2["Name"] = "Rock Joe ";
			row2["Address"] = "King of Prusssia, PA";
			custTable.Rows.Add(row2);

			DataRow row3 = custTable.NewRow();
			row3["id"] = 1003;
			row3["Name"] = "Miranda ";
			row3["Address"] = "279 P. Avenue, Bridgetown, PA";
			custTable.Rows.Add(row3);

			row3.RejectChanges();
			MessageBox.Show(row3.RowState.ToString());
			row2.Delete();
			MessageBox.Show(row2.RowState.ToString());
			
			// Bind data set to the data grid			
			dataGrid1.DataSource = ds.DefaultViewManager;			
		}
 
	}
}



