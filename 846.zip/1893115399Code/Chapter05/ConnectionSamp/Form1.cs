using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;


namespace ConnectionSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button Access2000;
		private System.Windows.Forms.Button SqlServer2000;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Access2000 = new System.Windows.Forms.Button();
			this.SqlServer2000 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// Access2000
			// 
			this.Access2000.Location = new System.Drawing.Point(32, 16);
			this.Access2000.Name = "Access2000";
			this.Access2000.Size = new System.Drawing.Size(152, 32);
			this.Access2000.TabIndex = 0;
			this.Access2000.Text = "OleDb - Access 2000";
			this.Access2000.Click += new System.EventHandler(this.Access2000_Click);
			// 
			// SqlServer2000
			// 
			this.SqlServer2000.Location = new System.Drawing.Point(224, 16);
			this.SqlServer2000.Name = "SqlServer2000";
			this.SqlServer2000.Size = new System.Drawing.Size(168, 32);
			this.SqlServer2000.TabIndex = 1;
			this.SqlServer2000.Text = "SQL Server 2000";
			this.SqlServer2000.Click += new System.EventHandler(this.SqlServer2000_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(400, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.SqlServer2000,
																		  this.Access2000});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		}

		private void Access2000_Click(object sender, System.EventArgs e)
		{
			// Create a Connection Object
			string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=c:\Northwind.mdb";
			OleDbConnection conn = new OleDbConnection(ConnectionString);

			// Open the connection
			if( conn.State != ConnectionState.Open)
				conn.Open();

			// Show the connection properties
			MessageBox.Show( "Connection String :"+conn.ConnectionString 
				+", DataSource :"+ conn.DataSource.ToString()
				+", Provider :"+ conn.Provider.ToString() 
				+", Server Version:"+ conn.ServerVersion.ToString()
				+", Connection Time Out:"+ conn.ConnectionTimeout.ToString() );

			// Close the connection
			if( conn.State == ConnectionState.Open)
				conn.Close();		
		}

		private void SqlServer2000_Click(object sender, System.EventArgs e)
		{
			// Create a Connection Object
            string ConnectionString ="Integrated Security=SSPI;" +
                                     "Initial Catalog=Northwind;" +
                                     "Data Source=localhost;";
			SqlConnection conn = new SqlConnection(ConnectionString);

          //  OleDbConnection conn = new OleDbConnection(ConnectionString);

			// Open the connection
			if( conn.State != ConnectionState.Open)
				conn.Open();


			// Show the connection properties
			MessageBox.Show( "Connection String :"+conn.ConnectionString 
				+ ", Workstation Id:"+ conn.WorkstationId.ToString()
				+", Packet Size :"+ conn.PacketSize.ToString()
                +", Server Version "+ conn.ServerVersion.ToString()
				+", DataSource :"+ conn.DataSource.ToString()
				+", Server Version:"+ conn.ServerVersion.ToString()
				+", Connection Time Out:"+ conn.ConnectionTimeout.ToString() );

			// Close the connection
			if( conn.State == ConnectionState.Open)
				conn.Close();		
		}
	}
}



