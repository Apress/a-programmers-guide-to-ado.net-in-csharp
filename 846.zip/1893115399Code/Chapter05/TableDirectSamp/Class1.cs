using System;
using System.Data;
using System.Data.OleDb;

namespace TableDirectSamp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// Create a Connection Object
			string ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source=c:\\Northwind.mdb";           
			OleDbConnection conn = new OleDbConnection(ConnectionString);
  
			OleDbCommand cmd = new OleDbCommand();
			cmd.Connection = conn;
			cmd.CommandText = "Customers";

			cmd.CommandType = CommandType.TableDirect;
           
			conn.Open();
			OleDbDataReader reader = cmd.ExecuteReader();

			Console.WriteLine("Customer Id, Contact Name, Company Name");
			Console.WriteLine("=======================================");
            
			while (reader.Read())
			{
				Console.Write(reader["CustomerID"].ToString());
				Console.Write(", "+ reader["ContactName"].ToString());
				Console.WriteLine(", "+ reader["CompanyName"].ToString());
			}
        
			// release objects
			reader.Close();
			conn.Close();                  
          
		}
	}

}
