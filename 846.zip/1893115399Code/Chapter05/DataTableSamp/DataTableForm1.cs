using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.Common;

namespace DataTableSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;

		// Put the next line into the Declarations section.
		private System.Data.DataSet dtSet;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
        {
            InitializeComponent();

            CreateCustomersTable();
            CreateOrdersTable();
            BindData();     
        }
	
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(16, 8);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(384, 240);
			this.dataGrid1.TabIndex = 0;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(416, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dataGrid1});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		// This method creates Customers table		
		private void CreateCustomersTable()
		{
			// Create a new DataTable.
			System.Data.DataTable custTable = new DataTable("Customers");
			DataColumn dtColumn;
			DataRow myDataRow;
 
			// Create id Column
			dtColumn = new DataColumn();
			dtColumn.DataType = System.Type.GetType("System.Int32");
			dtColumn.ColumnName = "id";
			dtColumn.Caption = "Cust ID";
			dtColumn.ReadOnly = true;
			dtColumn.Unique = true;
			// Add id Column to the DataColumnCollection.
			custTable.Columns.Add(dtColumn);
 
			// Create Name column.
			dtColumn = new DataColumn();
			dtColumn.DataType = System.Type.GetType("System.String");
			dtColumn.ColumnName = "Name";
			dtColumn.Caption = "Cust Name";
			dtColumn.AutoIncrement = false;
			dtColumn.ReadOnly = false;
			dtColumn.Unique = false;
			// Add Name column to the table.
			custTable.Columns.Add(dtColumn);


			// Create Address column.
			dtColumn = new DataColumn();
			dtColumn.DataType = System.Type.GetType("System.String");
			dtColumn.ColumnName = "Address";
			dtColumn.Caption = "Address";
			dtColumn.ReadOnly = false;
			dtColumn.Unique = false;
			// Add Address column to the table.
			custTable.Columns.Add(dtColumn);
 
			// Make the ID column the primary key column.
			DataColumn[] PrimaryKeyColumns = new DataColumn[1];
			PrimaryKeyColumns[0] = custTable.Columns["id"];
			custTable.PrimaryKey = PrimaryKeyColumns;
 
			// Instantiate the DataSet variable.
			dtSet = new DataSet("Customers");
			// Add the custTable to the DataSet.
			dtSet.Tables.Add(custTable);
 
			// Add rows to the custTable using its NewRow method
			// I add three customers with thier addresses, name and id
			myDataRow = custTable.NewRow();
			myDataRow["id"] = 1001;
			myDataRow["Address"] = "43 Lanewood Road, Cito, CA";
			myDataRow["Name"] = "George Bishop ";
			custTable.Rows.Add(myDataRow);

			myDataRow = custTable.NewRow();
			myDataRow["id"] = 1002;
			myDataRow["Name"] = "Rock Joe ";
			myDataRow["Address"] = "King of Prusssia, PA";
			custTable.Rows.Add(myDataRow);

			myDataRow = custTable.NewRow();
			myDataRow["id"] = 1003;
			myDataRow["Name"] = "Miranda ";
			myDataRow["Address"] = "279 P. Avenue, Bridgetown, PA";
			custTable.Rows.Add(myDataRow);
			
		}
 

		// This method creates Orders table with 
		private void CreateOrdersTable()
		{
			// Create Orders table.
			DataTable ordersTable = new DataTable("Orders");
			DataColumn dtColumn;
			DataRow dtRow;
 
			// Create OrderId column
			dtColumn = new DataColumn();
			dtColumn.DataType= System.Type.GetType("System.Int32");
			dtColumn.ColumnName = "OrderId";
			dtColumn.AutoIncrement = true;
			dtColumn.Caption = "Order ID";
			dtColumn.ReadOnly = true;
			dtColumn.Unique = true;
			ordersTable.Columns.Add(dtColumn);
 
			// Create Name column.
			dtColumn = new DataColumn();
			dtColumn.DataType= System.Type.GetType("System.String");
			dtColumn.ColumnName = "Name";
			dtColumn.Caption = "Item Name";
			ordersTable.Columns.Add(dtColumn);
 
			// Create CustId column which reprence CustId from 
			// the custTable
			dtColumn = new DataColumn();
			dtColumn.DataType= System.Type.GetType("System.Int32");
			dtColumn.ColumnName = "CustId";
			dtColumn.AutoIncrement = false;
			dtColumn.Caption = "CustId";
			dtColumn.ReadOnly = false;
			dtColumn.Unique = false;
			ordersTable.Columns.Add(dtColumn);

			// Create Description column.
			dtColumn = new DataColumn();
			dtColumn.DataType= System.Type.GetType("System.String");
			dtColumn.ColumnName = "Description";
			dtColumn.Caption = "Description Name";
			ordersTable.Columns.Add(dtColumn);

			// Add ordersTable to the dataset
			dtSet.Tables.Add(ordersTable);

            // Add two rows to Customer Id 1001
			dtRow = ordersTable.NewRow();
			dtRow["OrderId"] = 0;
			dtRow["Name"] = "ASP Book";
			dtRow["CustId"] = 1001 ;
			dtRow["Description"] = "Same Day" ;
			ordersTable.Rows.Add(dtRow);
			
			dtRow = ordersTable.NewRow();
			dtRow["OrderId"] = 1;
			dtRow["Name"] = "C# Book";
			dtRow["CustId"] = 1001 ;
			dtRow["Description"] = "2 Day Air" ;
			ordersTable.Rows.Add(dtRow);

			// Add two rows to Customer Id 1002
			dtRow = ordersTable.NewRow();
			dtRow["OrderId"] = 2;
			dtRow["Name"] = "Data Quest";
			dtRow["Description"] = "Monthly Magazine";
			dtRow["CustId"] = 1002 ;
			ordersTable.Rows.Add(dtRow);

			dtRow = ordersTable.NewRow();
			dtRow["OrderId"] = 3;
			dtRow["Name"] = "PC Magazine";
			dtRow["Description"] = "Monthly Magazine";
			dtRow["CustId"] = 1002 ;
			ordersTable.Rows.Add(dtRow);

			// Add two rows to Customer Id 1003
			dtRow = ordersTable.NewRow();
			dtRow["OrderId"] = 4;
			dtRow["Name"] = "PC Magazine";
			dtRow["Description"] = "Monthly Magazine";
			dtRow["CustId"] = 1003 ;
			ordersTable.Rows.Add(dtRow);

			dtRow = ordersTable.NewRow();
			dtRow["OrderId"] = 5;
			dtRow["Name"] = "C# Book";
			dtRow["CustId"] = 1003 ;
			dtRow["Description"] = "2 Day Air" ;
			ordersTable.Rows.Add(dtRow);			

		}
 
		// This method creates a customer order relationship and binds data tables 
        // to the data grid cotnrol using data set.
        private void BindData()
        {
            DataRelation dtRelation;
            DataColumn CustCol = dtSet.Tables["Customers"].Columns["id"];
            DataColumn orderCol = dtSet.Tables["Orders"].Columns["CustId"];
            
            dtRelation = new DataRelation("CustOrderRelation", CustCol, orderCol);
            dtSet.Tables["Orders"].ParentRelations.Add(dtRelation);

            dataGrid1.SetDataBinding(dtSet,"Customers");
        }       


	}

}




