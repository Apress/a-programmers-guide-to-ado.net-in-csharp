using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;


namespace DataAdapterSamp1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button OleDbDataAdapter;
		private System.Windows.Forms.Button SqlDataAdapter;
		private System.Windows.Forms.DataGrid dataGrid1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.OleDbDataAdapter = new System.Windows.Forms.Button();
			this.SqlDataAdapter = new System.Windows.Forms.Button();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// OleDbDataAdapter
			// 
			this.OleDbDataAdapter.Location = new System.Drawing.Point(16, 16);
			this.OleDbDataAdapter.Name = "OleDbDataAdapter";
			this.OleDbDataAdapter.Size = new System.Drawing.Size(136, 32);
			this.OleDbDataAdapter.TabIndex = 0;
			this.OleDbDataAdapter.Text = "OleDb DataAdapter";
			this.OleDbDataAdapter.Click += new System.EventHandler(this.OleDbDataAdapter_Click);
			// 
			// SqlDataAdapter
			// 
			this.SqlDataAdapter.Location = new System.Drawing.Point(176, 16);
			this.SqlDataAdapter.Name = "SqlDataAdapter";
			this.SqlDataAdapter.Size = new System.Drawing.Size(168, 32);
			this.SqlDataAdapter.TabIndex = 1;
			this.SqlDataAdapter.Text = "SQL DataAdapter";
			this.SqlDataAdapter.Click += new System.EventHandler(this.SqlDataAdapter_Click);
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(16, 72);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(336, 192);
			this.dataGrid1.TabIndex = 2;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(376, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dataGrid1,
																		  this.SqlDataAdapter,
																		  this.OleDbDataAdapter});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void OleDbDataAdapter_Click(object sender, System.EventArgs e)
        {
            // Create a Connection Object
            string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=c:\Northwind.mdb";
            string SQL = "SELECT * FROM Orders";

            OleDbConnection conn = new OleDbConnection(ConnectionString);
            // Open the connection
            conn.Open();
            
            // Create an OleDbDataAdapter object
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            adapter.SelectCommand = new OleDbCommand(SQL, conn);
        
            // Create DataSet Object 
            DataSet ds = new DataSet("Orders");         
            // Call DataAdapter's Fill method to fill data from the 
            // DataAdapter to the DataSet 
            adapter.Fill(ds);

            // Bind data set to a DataGrid control
            dataGrid1.DataSource = ds.DefaultViewManager;           
        }

		private void SqlDataAdapter_Click(object sender, System.EventArgs e)
        {
        
            string ConnectionString ="Integrated Security=SSPI;" +
                "Initial Catalog=Northwind;" +
                "Data Source=localhost;";
            string SQL = "SELECT CustomerID, CompanyName FROM Customers";

            SqlConnection conn = new SqlConnection(ConnectionString);

            // Open the connection
            conn.Open();

            // Create a SqlDataAdapter object
            SqlDataAdapter adapter = new SqlDataAdapter(SQL, conn);

            // Call DataAdapter's Fill method to fill data from the 
            // DataAdapter to the DataSet 
            DataSet ds = new DataSet("Customers");
            adapter.Fill(ds);

            // Bind data set to a DataGrid control
            dataGrid1.DataSource = ds.DefaultViewManager;           
        }
	}
}
