using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;


namespace ConnectionPoolingSamp
{
	class Class1
	{
		static void Main(string[] args)
		{
			// Connection and SQL strings
            string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=c:\Northwind.mdb";
            string SQL = "SELECT OrderID, Customer, CustomerID FROM Orders";

            // Create connection object
            OleDbConnection conn = new OleDbConnection(ConnectionString);       
            
            conn.Open();

            // do something

            conn.Close();
            OleDbConnection.ReleaseObjectPool();

		}
	}
}
