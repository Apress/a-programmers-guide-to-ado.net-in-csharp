using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace DataReaderSamp2
{
	class Class1
	{
		static void Main(string[] args)
        {
        
            // Create a Connection string
            string ConnectionString ="Integrated Security=SSPI;" +
                "Initial Catalog=Northwind;" +
                "Data Source=localhost;";
            string SQL = "SELECT * FROM Customers; SELECT * FROM Orders";

            // Create a Connection object
            SqlConnection conn = new SqlConnection(ConnectionString);
            // Create a Command Object
            SqlCommand cmd = new SqlCommand(SQL, conn);
            
            conn.Open();

            // Call ExecuteReader to return a DataReader
            SqlDataReader reader = cmd.ExecuteReader();

            int counter = 0;

            string str ="";
            bool bNextResult = true;
            while(bNextResult == true)
            {

                while (reader.Read())
                {
                    str += reader.GetValue(0).ToString() +"\n";           
                    counter ++;
                    if (counter == 10)
                        break;
                }
                MessageBox.Show(str);
                bNextResult = reader.NextResult();
            }

            // Release resources
            reader.Close();
            conn.Close();
			Console.Read();
        }
	}
}
