using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data.Common;
using System.Windows.Forms;


namespace TableMappingSamp1
{
	class Class1
	{
		static void Main(string[] args)
		{
			// Create a Connection Object
			string ConnectionString ="Integrated Security=SSPI;" +
				"Initial Catalog=Northwind;" +
				"Data Source=localhost;";
			SqlConnection conn = new SqlConnection(ConnectionString);

			// Open the connection
			conn.Open();

			try
			{
				DataTableMapping myMapping = new DataTableMapping("Orders", "mapOrders");
				SqlDataAdapter adapter = new SqlDataAdapter("Select * From Orders",	conn);
				adapter.TableMappings.Add(myMapping);

				DataSet ds = new DataSet();

				adapter.Fill(ds, "mapOrders");
				MessageBox.Show(ds.Tables[0].OrderID.ToString());
			}
			catch(SqlException ex)
			{
				MessageBox.Show(ex.Message.ToString());
			}



		}
	}
}
