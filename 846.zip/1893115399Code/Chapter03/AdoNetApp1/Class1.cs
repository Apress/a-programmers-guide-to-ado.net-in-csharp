using System;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;

// First ADO .NET Application
// In this appication, I read data from Norhtwind database
// And display on the console.

namespace AdoNetApp1
{
	class AdoNetAppCls
	{
		static void Main(string[] args)
		{
			//  Form the connection string for an OleDb 
			// Connection which contains the OLE-DB Provider
			// string for Access and the name of the Database, 
			//  Northwind
			string connectionString = "Provider=Microsoft.JET.OLEDB.4.0;"
				+" data source=C:\\Northwind.mdb";

			//  Form the connection object to the Northwind 
			// database, passing it the connection string
			OleDbConnection conn = new OleDbConnection(connectionString);

			// SELECT SQL Query
			string sql = "SELECT CustomerID, ContactName,"+
				"ContactTitle FROM Customers";
                                              
			// Create a command object with the SELECT Query
			OleDbCommand cmd = new OleDbCommand(sql, conn);

			// Open the connection to the Database
			conn.Open();

			// Create a data reader object and call 
			// OleDbCommand.ExecuteReaderto return data in the reader
			OleDbDataReader reader;
			reader = cmd.ExecuteReader();

			// Display data
			Console.WriteLine("Contact Name, Contact Title");
			Console.WriteLine("=======================");
            
			// Read until reader has records
			while (reader.Read()) 
			{
				Console.Write(reader.GetString(0).ToString() + " ," );
				Console.Write(reader.GetString(1).ToString() + " ," );
				Console.WriteLine("");
			}

			// Close reader
			reader.Close();
			// Close the connection
			conn.Close();
            
		}
	}
}
