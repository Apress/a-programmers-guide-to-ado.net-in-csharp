using System;
class ConversionSamp
{
	static void Main() 
	{
		Object obj = 123;
		int num1 = (int)obj;

		Console.WriteLine(num1.ToString());
		Console.WriteLine(obj.ToString());
	}
}
