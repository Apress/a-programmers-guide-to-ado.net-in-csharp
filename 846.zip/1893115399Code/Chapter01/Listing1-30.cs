using System;  
public class myClass 
{
	public static void ReturnData(out int iVal1, out int iVal2) 
	{
		iVal1 = 2;
		iVal2 = 5;   
	}

	public static void Main() 
	{
		int iV1, iV2;   // variable need not be initialized
		ReturnData(out iV1, out iV2);
		Console.WriteLine(iV1);
		Console.WriteLine(iV2);
	}
}
