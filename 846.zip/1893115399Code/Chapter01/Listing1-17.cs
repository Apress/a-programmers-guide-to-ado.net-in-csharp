using System;

public class ArraySample  
{

	public static void Main()  
	{
		// Create and initialize a new Array instance.
		Array strArr = Array.CreateInstance( typeof(String), 3 );
		strArr.SetValue( "Mahesh", 0 );
		strArr.SetValue( "Chand", 1 );
		strArr.SetValue( "Test Array", 2 );
        
		// Display the values of the Array.
		Console.WriteLine( "Initial Array values:" );
		for ( int i = strArr.GetLowerBound(0); i <= strArr.GetUpperBound(0); i++ )
			Console.WriteLine( strArr.GetValue( i ) );

		// Sort the values of the Array.
		Array.Sort(strArr );

		Console.WriteLine( "After sorting:" );
		for ( int i = strArr.GetLowerBound(0); i <= strArr.GetUpperBound(0); i++ )
			Console.WriteLine( strArr.GetValue( i ) );

		// Reverse values of the Array.
		Array.Reverse(strArr);

		for ( int i = strArr.GetLowerBound(0); i <= strArr.GetUpperBound(0); i++ )
			Console.WriteLine( strArr.GetValue( i ) );

	}
}
