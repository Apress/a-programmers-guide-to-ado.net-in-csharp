using System;

namespace ToStringSamp
{
	class Test
	{
		static void Main(string[] args)
		{
			int num1 = 12;
			float num2 = 3.05f;
			double num3 = 3.5;
			bool bl = true;

			Console.WriteLine(num1.ToString());
			Console.WriteLine(num2.ToString());
			Console.WriteLine(num3.ToString());
			Console.WriteLine(bl.ToString());

		}        
	}
}
