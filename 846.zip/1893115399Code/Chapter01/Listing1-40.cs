using System;

public class myClass 
{
	public static void Main() 
	{
		int aValue = 5;
		try
		{
			int[] MySequence = new int[]{3,5,6};
			aValue = MySequence[4];
		}
		catch(Exception e)
		{
			System.Console.WriteLine("Caught the exception -� {0}", 
				e.Message.ToString());
		}
		finally
		{
			// do any clean up
			//      ����
			System.Console.WriteLine("The value = {0}", aValue);
			System.Console.ReadLine();
		}

	}
}
