using System;

delegate void MyDelegate();

class Test
{
	static void TestMethod() 
	{
		System.Console.WriteLine("Test Method called");
	}
	static void Main() 
	{
		MyDelegate del = new MyDelegate(TestMethod);
		del();
	}
}
