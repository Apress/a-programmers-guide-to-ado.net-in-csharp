using System;  
public class myClass 
{
	public static void ReturnData(ref int iVal1, ref int iVal2, ref int iVal3 ) 
	{
		iVal1 += 2;
		iVal2 = iVal2*iVal2;
		iVal3 = iVal2 + iVal1;
	}

	public static void Main() 
	{
		int iV1, iV2, iV3;   // variable need not be initialized
		iV1 = 3;
		iV2 = 10;
		iV3 = 1;
		ReturnData(ref iV1, ref iV2, ref iV3 );
		Console.WriteLine(iV1);
		Console.WriteLine(iV2);
		Console.WriteLine(iV3);
	}

}
