using System;

interface MyInterface
{
	void TestMethod(); 
}

interface MyInterface2
{
	int TestMethod2(int a, int b);  
}

class MyClass : MyInterface, MyInterface2
{
    

	public static void Main()
	{   
		int num1 = 23;
		int num2 = 6;

		MyClass cls = new MyClass();
		cls.TestMethod();
		int tot = cls.TestMethod2(num1, num2);
		Console.WriteLine(tot.ToString());

	}
	public void TestMethod() 
	{
		Console.WriteLine("Test Method");
	}
	public int TestMethod2(int a, int b) 
	{
		return a + b;
	}
}
