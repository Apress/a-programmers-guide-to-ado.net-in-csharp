using System;

public delegate void BoilerStatus(int temp, int pressure, ref string status);

public class  Boiler
{
	BoilerStatus BoilerDel1;
	BoilerStatus BoilerDel2;

	public void CurrentStatus(int t, int p, ref string res)
	{
		if(t >= 50 && p >= 60)
		{
			Console.WriteLine("Status High");
			res = "High";
			return;
		}
		else if(t < 20 || p < 20)
		{
			Console.WriteLine("Status Low"); 
			res = "Low";
			return;
		}
		else 
		{
			Console.WriteLine("Status Normal");
			res = "Normal";
		}

	}

	public void PreStatus(int t, int p, ref string res)
	{
		if(t >= 50 && p >= 60)
		{
			Console.WriteLine("Status High");
			res = "High";
			return;
		}
		else if(t < 20 || p < 20)
		{
			Console.WriteLine("Status Low"); 
			res = "Low";
			return;
		}
		else 
		{
			Console.WriteLine("Status Normal");
			res = "Normal";
		}
	}

	public static int Main(string[] args)
	{
		Boiler boiler = new Boiler();
		string outres = "";
		boiler.BoilerDel1 = new BoilerStatus(boiler.CurrentStatus);
		boiler.BoilerDel2 = new BoilerStatus(boiler.PreStatus);
 
		boiler.BoilerDel1(55, 70, ref outres);
		boiler.BoilerDel2(22, 76, ref outres);

		Console.WriteLine();
		return 0;

	}
}
