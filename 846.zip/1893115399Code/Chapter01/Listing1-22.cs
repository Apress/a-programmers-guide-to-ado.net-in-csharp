using System;

class Test
{
	static void Main() 
	{
		int num1 = 123;
		int num2 = 34;

		int res = num1 + num2;
		Console.WriteLine(res.ToString());

		res = -(res);
		Console.WriteLine(res.ToString());
	}
}
