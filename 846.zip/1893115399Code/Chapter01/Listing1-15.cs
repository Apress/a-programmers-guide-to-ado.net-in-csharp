class Test
{
	static void Main() 
	{
		// array of integers
		int[] nums = new int[5];
		// array of strings
		string[] names = new string[2];

		for (int i = 0; i < nums.Length; i++)
			nums[i] = i + 2;
		names[0] = "Mahesh";
		names[1] = "Chand";
        
		for (int i = 0; i < nums.Length; i++)
			System.Console.WriteLine("num[{0}] = {1}", i, nums[i]);
		System.Console.WriteLine
			(names[0].ToString() + " " + names[1].ToString() );
	}
}
