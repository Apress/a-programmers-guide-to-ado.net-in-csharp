using System;
class myClass
{
	public int Sum(int a, int b)
	{ 
		int res = a + b;
		return res;
	}

	public float Sum (float a, float b)
	{
		float res = a + b;
		return res;
	}

	public long Sum (long a, long b)
	{
		long res = a + b;
		return res;
	}

	public long Sum (long a, long b, long c)
	{
		long res = a + b + c;
		return res;
	}

	public long Sum (int[] a)
	{
		int res = 0;
		for (int i=0; i < a.Length; i++)
		{
			res += a[i];
		}
		return res;
	}

	public void Sum()
	{
		//return nothing
	}
}

class TestmyClass
{
	static void Main() 
	{
		myClass cls = new myClass();
		int intTot = cls.Sum(5, 8);
		Console.WriteLine("Return integer sum:"+ intTot.ToString());
		cls.Sum();
		long longTot = cls.Sum(Int64.MaxValue - 30, 8);
		Console.WriteLine("Return long sum:"+ longTot.ToString());
		float floatTot = cls.Sum(Single.MaxValue-50, 8);
		Console.WriteLine("Return float sum:"+ floatTot.ToString());        
		int[] myArray = new int[] {1, 3, 5, 7, 9}; 
		Console.WriteLine("Return sum of array = {0}",  
			cls.Sum(myArray).ToString());

	}
}
