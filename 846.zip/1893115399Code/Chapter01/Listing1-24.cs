using System;

public class MyClass 
{
	public static void Main() 
	{
		int i = 3;
		switch(i)
		{
			case 1 :
				Console.WriteLine("one");
				break;
			case 2 :
				Console.WriteLine("two");
				break;
			case 3 :
				Console.WriteLine("three");
				break;
			case 4 :
				Console.WriteLine("four");
				break;
			case 5 :
				Console.WriteLine("five");
				break;
			default :
				Console.WriteLine("None of the above");
				break;
		} 
	}
}
