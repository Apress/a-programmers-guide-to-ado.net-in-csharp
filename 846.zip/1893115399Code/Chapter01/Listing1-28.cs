using System;
class myClass
{
	public int Sum(int a, int b)
	{ 
		int res = a + b;
		return res;
	}
}

class TestmyClass
{
	static void Main() 
	{
		myClass cls = new myClass();
		int total = cls.Sum(5, 8);
		Console.WriteLine(total.ToString());
	}
}
