using System;
class ConversionSamp
{
	static void Main() 
	{
		int num1 = 123;
		Object obj = num1;

		Console.WriteLine(num1.ToString());
		Console.WriteLine(obj.ToString());
	}
}
