using System;
class myClass
{
	public int iCounter, iTotal;
	public myClass () 
	{
		iCounter = 0;
		iTotal = 0;
	}
	public myClass (int iCount, int iTot) 
	{
		iCounter = iCount;
		iTotal = iTot;
	}
}

class TestmyClass
{
	static void Main() 
	{
		myClass cls = new myClass();
		myClass cls1 = new myClass(3, 4);

		Console.WriteLine(cls1.iCounter.ToString());
		Console.WriteLine(cls1.iTotal.ToString());
	}
}
