using System;

interface MyInterface
{
	void TestMethod(); 
}

class MyClass : MyInterface
{
	public static void Main()
	{   
		MyClass cls = new MyClass();
		cls.TestMethod();
	}
	public void TestMethod() 
	{
		Console.WriteLine("Test Method");
	}
}
