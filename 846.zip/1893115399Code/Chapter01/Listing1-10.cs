using System;

struct CarRec
{
	public string Name;
	public string Model;
	public int Year;
}
 
class TestStructureType
{
	public static void Main()
	{
		CarRec rec;
		rec.Name = "Honda";
		rec.Model = "Accord";
		rec.Year = 1999;

		Console.WriteLine("Car Name: " +rec.Name);
		Console.WriteLine("Car Model: " +rec.Model);
		Console.WriteLine("Car Year: "+ rec.Year);
	}
}
