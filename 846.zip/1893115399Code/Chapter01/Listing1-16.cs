using System;

public class ArraySample  
{

	public static void Main()  
	{

		// Create and initialize a new arrays
		int[] intArr = new int[5] { 1, 2, 3, 4, 5};
		Object[] objArr = new Object[5] { 10, 20, 30, 40, 50};
    
		foreach ( int i in intArr )  
		{
			Console.Write(i);
			Console.Write(",");
		}
		Console.WriteLine();
		foreach ( Object i in objArr )  
		{
			Console.Write(i);
			Console.Write(",");
		}
		Console.WriteLine();
        

		// Copy one first 3 elements of intArr to objArr
		Array.Copy(intArr, objArr, 3 );

		Console.WriteLine("After copying");
		foreach ( int i in intArr )  
		{
			Console.Write(i);
			Console.Write(",");
		}
		Console.WriteLine();    
		foreach ( Object i in objArr )  
		{
			Console.Write(i);
			Console.Write(",");
		}
		Console.WriteLine();
        
            
	}
}
