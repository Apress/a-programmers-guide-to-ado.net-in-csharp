using System;

namespace ConsoleSamp
{
	class Class1
	{
		static void Main(string[] args)
		{
			Console.Write("Standard I/O Sample");
			Console.WriteLine("");
			Console.WriteLine("===================");
			Console.WriteLine("Enter your name... ");
			String name = Console.ReadLine();
			Console.WriteLine("Output: Your name is: "+ name); 
		}
	}
}
