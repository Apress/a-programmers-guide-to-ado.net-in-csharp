class myClass
{
	public int iCounter, iTotal;
	public myClass () 
	{
		iCounter = 0;
		iTotal = 0;
	}
	public myClass (int iCount, int iTot) 
	{
		iCounter = iCount;
		iTotal = iTot;
	}
}
