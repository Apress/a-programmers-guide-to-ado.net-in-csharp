namespace BoilerEvent
{
using System;

public class BoilerEventSink
{
	// Normal status message
	public void StatusNormal(string status)
	{
			Console.WriteLine("Normal Staus from Event Sink");
	}

	// High status message
	public void StatusHigh(string status)
	{
		Console.WriteLine("High Staus from Event Sink");
	}

	// Low status message
	public void StatusLow(string status)
	{
			Console.WriteLine("Low Staus from Event Sink");
	}
}

// Event caller mailn application
public class BoilerCallerApp
{
	public static int Main(string[] args)
	{
		//Boiler object
		Boiler boiler1 = new Boiler();

		// Make sink object.
		BoilerEventSink bsink = new BoilerEventSink();

		Boiler.BoilerStatus += new Boiler.EngineHandler(bsink.StatusNormal);
		Boiler.BoilerStatus += new Boiler.EngineHandler(bsink.StatusHigh);
		Boiler.BoilerStatus += new Boiler.EngineHandler(bsink.StatusLow);

		// Set current status
		boiler1.CurrentStatus(55, 74, "");
		return 0;
	}
}

}
