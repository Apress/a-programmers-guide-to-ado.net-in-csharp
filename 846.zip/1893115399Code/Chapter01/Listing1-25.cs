using System;

class myClass
{
	static myClass()
	{
		Console.WriteLine("Initialize Class�");
		// Do some stuff  
	}
	public static void foo() 
	{
		Console.WriteLine("foo");
	}
}
class Test
{
	static void Main() 
	{
		myClass.foo();  // calls myClass static constructor and then foo
	}
}
