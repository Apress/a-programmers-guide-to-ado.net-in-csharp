using System;
class myClass
{
	private bool bGender;
	private int intAge;

	// Gender property. 
	public bool MaleGender 
	{
		get 
		{
			return bGender;
		}
		set 
		{
			bGender = value;
		}
	}
	// Age property
	public int Age 
	{
		get 
		{
			return intAge;
		}
		set 
		{
			intAge = value;
		}
	}

}

class TestmyClass
{
	static void Main() 
	{
		myClass cls = new myClass();

		// Set properties values
		cls.MaleGender = true;
		cls.Age = 25;
        
		if(cls.MaleGender)
		{
			Console.WriteLine("The Gender is Male");
			Console.WriteLine("Age is "+ cls.Age.ToString());
		}
     
	}
}
