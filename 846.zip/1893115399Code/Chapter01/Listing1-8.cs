using System;

namespace ToStringSamp
{
	class Test
	{
		static void Main(string[] args)
		{
			int num1 = 8;
			float num2 = 162.034f;
        
			Console.WriteLine(num1.ToString());
			Console.WriteLine(num2.ToString()); 

		}        
	}
}
