namespace BoilerEvent
{
  using System;

  public class Boiler
  {
    public delegate void EngineHandler(int temp);
    public static event EngineHandler BoilerStatus;
  
  
    public Boiler()
    {
    }

    public void SetBoilerReadings(int temp, int pressure)
    { 
    
      if ( BoilerStatus != null)
      {
        if(temp >= 50 && pressure >= 60)
        {
          BoilerStatus(temp); 
          Console.WriteLine("Boiler Status: Temprature High");
        }
        else if(temp < 20 || pressure < 20)
        {
          BoilerStatus(temp); 
          Console.WriteLine("Boiler Status: Temprature Low");
        }
        else 
          Console.WriteLine("Boiler Status: Temprature Normal");
      }
    }

  }

  public class BoilerEventSink
  {
    public void BoilerTempoMeter(int temp)
    {
      if (temp <= 0)
      {
        Console.WriteLine("Alarm: Boiler is switched off");
      }
    }   
  }

  // Event caller mailn application
  public class BoilerCallerApp
  {
    public static int Main(string[] args)
    {
      Boiler boiler1 = new Boiler();
      BoilerEventSink bsink = new BoilerEventSink();
      Boiler.BoilerStatus +=        
        new Boiler.EngineHandler(bsink.BoilerTempoMeter);
      boiler1.SetBoilerReadings(55, 74);
      boiler1.SetBoilerReadings(0, 54);
      boiler1.SetBoilerReadings(8, 23);
      return 0;
    }
  }
}
