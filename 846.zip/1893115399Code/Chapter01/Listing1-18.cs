using System;
class ConversionSamp
{
	static void Main() 
	{
		int num1 = 123;
		long num2 = num1;
		Console.WriteLine(num1.ToString());
		Console.WriteLine(num2.ToString());
	}
}
