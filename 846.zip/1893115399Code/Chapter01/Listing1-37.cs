using System;

// Base class A
class BaseClassA
{
	public void MethoidA()
	{ 
		Console.WriteLine("A Method Called"); 
	}
}
// Base class B is derived from BaseClassA
class BaseClassB: BaseClassA
{
	public void MethoidB()
	{ 
		Console.WriteLine("B Method Called"); 
	}
}
class myClass
{
	static void Main() 
	{
		// Base class B
		BaseClassB b = new BaseClassB();

		// BaseClassB method
		b.MethoidB();
		//BaseClassA method through BaseClassB
		b.MethoidA();
	}
}   
