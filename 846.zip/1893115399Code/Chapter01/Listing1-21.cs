using System;
class VarAccess
{
	class AccessCls
	{
		public int num1 = 123;
	}

	static void Main() 
	{
		AccessCls cls = new AccessCls();
		int num1 = 98;
		num1 = cls.num1;
		Console.WriteLine(num1.ToString());      
	}
}
