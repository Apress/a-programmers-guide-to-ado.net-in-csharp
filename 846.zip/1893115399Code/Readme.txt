Book: A Programmer's Guide to ADO.NET in C#. Author: Mahesh Chand

Guidelines to compile and run source code.
==========================================

This reademe.txt file contains guidelines for how to use soruce code samples. Unzip 1893115399Code.zip file. It will copy all source code samples in c:\1893115399Code directory. 

Each chapter of the book has its own directory. For example, Chapter03 contains source code samples for Chapter 3. All source code is written using Visual Studio .NET final release. Make sure your database path is correct.

Chapter 1: Create a console application, copy contents of cs file and build and run the project.

Chapter 2 - 5. All chapters has VS.NET projects. Just open the project, build and run. 

Chapter 6. This chapter has some VS.NET project, which you can direct open and run in VS.NET without any modifications. To run cs files, open any project and cut and paste contents of cs files to the project. Make sure you provide correct path of used files and atabases.

Chapter 7 - 8. Chapter 7 and 8 code also is in form of VS.NET projects. You need to deploy these projects on the Web server. Best way is to create empty projects by following steps in the book and cut and paste code from these projects to new projects. Again, make sure database is in correct path. For MyGuestBook application, GuestBook.mdb is available in Chapter07 directory.

Chapter 9 - 11. Again all projects are VS.NET projects. You need to make sure your database path is correct. 



