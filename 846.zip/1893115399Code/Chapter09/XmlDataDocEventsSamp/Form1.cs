using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml;

namespace XmlDataDocEventsSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button XmlDocumentBtn;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.XmlDocumentBtn = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// XmlDocumentBtn
			// 
			this.XmlDocumentBtn.Location = new System.Drawing.Point(32, 56);
			this.XmlDocumentBtn.Name = "XmlDocumentBtn";
			this.XmlDocumentBtn.Size = new System.Drawing.Size(184, 48);
			this.XmlDocumentBtn.TabIndex = 0;
			this.XmlDocumentBtn.Text = "XmlDocument Events";
			this.XmlDocumentBtn.Click += new System.EventHandler(this.XmlDocumentBtn_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.XmlDocumentBtn});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void XmlDocumentBtn_Click(object sender, System.EventArgs e)
		{
			XmlDocument xmlDoc = new XmlDocument();
			xmlDoc.LoadXml("<Record> Some Value </Record>");

			//Create the event handlers.
			xmlDoc.NodeChanged += 
				new XmlNodeChangedEventHandler(this.MyNodeChangedEvent);
			xmlDoc.NodeInserted += 
				new XmlNodeChangedEventHandler(this.MyNodeInsertedEvent);
			xmlDoc.NodeRemoved += 
				new XmlNodeChangedEventHandler(this.MyNodeRemovedEvent);

  
			XmlElement root = xmlDoc.DocumentElement;
			string str = root.ToString();

			XmlDocumentFragment xmlDocFragment = 
				xmlDoc.CreateDocumentFragment();
			xmlDocFragment.InnerXml=
				"<Fragment><SomeData>Fragment Data</SomeData></Fragment>";
        
			// Replace Node
			XmlElement rootNode = xmlDoc.DocumentElement;   
			rootNode.ReplaceChild(xmlDocFragment, rootNode.LastChild);

			// Remove Node
			XmlNode node = xmlDoc.LastChild;
			xmlDoc.RemoveChild(node);

		}

		public void MyNodeChangedEvent(Object src, 
			XmlNodeChangedEventArgs args)
		{
			MessageBox.Show
				("Node Changed Event Fired for node "+ args.Node.Name);
			if (args.Node.Value != null)
			{
				MessageBox.Show(args.Node.Value);
			}           
		}


		
		public void MyNodeInsertedEvent(Object src, 
			XmlNodeChangedEventArgs args)
		{
			MessageBox.Show
				("Node Inserted Event Fired for node "+ args.Node.Name);
			if (args.Node.Value != null)
			{
				MessageBox.Show(args.Node.Value);
			}       
		}



		public void MyNodeRemovedEvent(Object src, 
			XmlNodeChangedEventArgs args)
		{
			MessageBox.Show
				("Node Removed Event Fired for node "+ args.Node.Name);
			if (args.Node.Value != null)
			{
				MessageBox.Show(args.Node.Value);
			}       
		}

	}
}
