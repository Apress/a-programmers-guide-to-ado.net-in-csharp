using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace DataViewEventsSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(40, 40);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(168, 40);
			this.button1.TabIndex = 0;
			this.button1.Text = "button1";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
			
			OleDbConnection conn = new OleDbConnection();
			string strDSN = "Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source=C:\\Northwind.mdb";
			conn.ConnectionString = strDSN;
			string sql = 
				"SELECT EmployeeId, LastName, FirstName FROM Employees";
			// Opening Connection
			conn.Open();

			// Create a data adapter
			OleDbDataAdapter da = new OleDbDataAdapter(sql, conn);

			// Create and Fill DataSet            
			DataSet ds = new DataSet();
			da.Fill(ds, "Employees");

			DataView dv = ds.Tables["Employees"].DefaultView;

			// Add DataView Event Handlers
			dv.ListChanged  += new 
				System.ComponentModel.ListChangedEventHandler
				(OnListChanged);

			// Add a row to the DataView
			dv.AllowEdit = true;
			DataRowView rw = dv.AddNew();
			rw.BeginEdit();
			rw["FirstName"] = "FName";
			rw["LastName"] = "LName";
			rw.EndEdit();

			// Remove a row from the DataView
			if(dv.Count > 0)
			{
				dv.Delete(0);
				dv[0].Row.AcceptChanges();
			}
            
			// Close the connection
			conn.Close();

		}

		protected static void OnListChanged(object sender, 
			System.ComponentModel.ListChangedEventArgs args)
		{
			MessageBox.Show("ListChanged: Type = " + args.ListChangedType
				+ ", OldIndex = " + args.OldIndex
				+ ", NewIndex = " + args.NewIndex );
		}

	}
}
