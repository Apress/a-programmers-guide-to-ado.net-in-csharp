using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SqlConnectionEventsSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button StateChangeEventBtn;
		private System.Windows.Forms.Button InfoMessageBtn;
		private System.Data.SqlClient.SqlConnection sqlConnection1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.StateChangeEventBtn = new System.Windows.Forms.Button();
			this.InfoMessageBtn = new System.Windows.Forms.Button();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.SuspendLayout();
			// 
			// StateChangeEventBtn
			// 
			this.StateChangeEventBtn.Location = new System.Drawing.Point(8, 24);
			this.StateChangeEventBtn.Name = "StateChangeEventBtn";
			this.StateChangeEventBtn.Size = new System.Drawing.Size(152, 32);
			this.StateChangeEventBtn.TabIndex = 0;
			this.StateChangeEventBtn.Text = "StateChange Event";
			this.StateChangeEventBtn.Click += new System.EventHandler(this.StateChangeEventBtn_Click);
			// 
			// InfoMessageBtn
			// 
			this.InfoMessageBtn.Location = new System.Drawing.Point(8, 72);
			this.InfoMessageBtn.Name = "InfoMessageBtn";
			this.InfoMessageBtn.Size = new System.Drawing.Size(152, 32);
			this.InfoMessageBtn.TabIndex = 1;
			this.InfoMessageBtn.Text = "InfoMessage Event";
			this.InfoMessageBtn.Click += new System.EventHandler(this.InfoMessageBtn_Click);
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.InfoMessage += new System.Data.SqlClient.SqlInfoMessageEventHandler(this.sqlConnection1_InfoMessage);
			this.sqlConnection1.StateChange += new System.Data.StateChangeEventHandler(this.sqlConnection1_StateChange);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.InfoMessageBtn,
																		  this.StateChangeEventBtn});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void StateChangeEventBtn_Click(object sender, System.EventArgs e)
        {
            try
            {
                // Create a Connection Object
                string ConnectionString ="Integrated Security=SSPI;" +
                    "Initial Catalog=Northwind;" +
                    "Data Source=localhost;";
                
                sqlConnection1.ConnectionString = ConnectionString;
                // Open the connection
                if( sqlConnection1.State != ConnectionState.Open)
                    sqlConnection1.Open();
                

                // Close the connection
                sqlConnection1.Close();

            }
            catch( Exception ex )
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void InfoMessageBtn_Click(object sender, System.EventArgs e)
        {
            try
            {
                // Create a Connection Object
                string ConnectionString ="Integrated Security=SSPI;" +
                    "Initial Catalog=Northwind;" +
                    "Data Source=localhost;";
                
                sqlConnection1.ConnectionString = ConnectionString;
                // Open the connection
                if( sqlConnection1.State != ConnectionState.Open)
                    sqlConnection1.Open();

                // Change database
                sqlConnection1.ChangeDatabase("Master");

                // Close the connection
                sqlConnection1.Close();

            }
            catch( Exception ex )
            {
                MessageBox.Show(ex.Message);
            }
        }

		// Connection InfoMessage Event Handler
        private void sqlConnection1_InfoMessage
            (object sender, System.Data.SqlClient.SqlInfoMessageEventArgs e)
        {
            int i;
            for (i=0; i < e.Errors.Count; i++ )
            {
                MessageBox.Show(e.Errors[i].Message);
            }
        }

        // Connection StateChange Event Handler
        private void sqlConnection1_StateChange
            (object sender, System.Data.StateChangeEventArgs e)
        {
            MessageBox.Show("Original State:" + e.OriginalState.ToString() 
                + ", Current State = " + e.CurrentState.ToString() );
        }
    }
}
