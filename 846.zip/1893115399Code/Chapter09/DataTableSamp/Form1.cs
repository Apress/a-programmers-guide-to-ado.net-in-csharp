using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DataTableSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button ColumnChange;
		private System.Windows.Forms.Button UpdateRow;
		private System.Windows.Forms.Button DeleteRow;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ColumnChange = new System.Windows.Forms.Button();
			this.UpdateRow = new System.Windows.Forms.Button();
			this.DeleteRow = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// ColumnChange
			// 
			this.ColumnChange.Location = new System.Drawing.Point(16, 32);
			this.ColumnChange.Name = "ColumnChange";
			this.ColumnChange.Size = new System.Drawing.Size(152, 40);
			this.ColumnChange.TabIndex = 0;
			this.ColumnChange.Text = "ColumnChange Event";
			this.ColumnChange.Click += new System.EventHandler(this.ColumnChange_Click);
			// 
			// UpdateRow
			// 
			this.UpdateRow.Location = new System.Drawing.Point(24, 96);
			this.UpdateRow.Name = "UpdateRow";
			this.UpdateRow.Size = new System.Drawing.Size(144, 40);
			this.UpdateRow.TabIndex = 1;
			this.UpdateRow.Text = "UpdateRow Event";
			this.UpdateRow.Click += new System.EventHandler(this.UpdateRow_Click);
			// 
			// DeleteRow
			// 
			this.DeleteRow.Location = new System.Drawing.Point(32, 168);
			this.DeleteRow.Name = "DeleteRow";
			this.DeleteRow.Size = new System.Drawing.Size(136, 40);
			this.DeleteRow.TabIndex = 2;
			this.DeleteRow.Text = "DeleteRow Event";
			this.DeleteRow.Click += new System.EventHandler(this.DeleteRow_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.DeleteRow,
																		  this.UpdateRow,
																		  this.ColumnChange});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void ColumnChange_Click(object sender, System.EventArgs e)
		{
			DataTable custTable = new DataTable("Customers");
			// add columns
			custTable.Columns.Add( "id", typeof(int) );
			custTable.Columns.Add( "name", typeof(string) );
			custTable.Columns.Add( "address", typeof(string) );

			// Add ColumnChanging and ColumnChanged event handlers
			custTable.ColumnChanging += 
				new DataColumnChangeEventHandler( Column_Changing );
			custTable.ColumnChanged += 
				new DataColumnChangeEventHandler( Column_Changed );

			// add Two rows
			custTable.Rows.Add( 
				new object[] { 1, "name1", "address1"} );
			custTable.Rows.Add( 
				new object[] { 2, "name2", "address2"} );
               
			custTable.AcceptChanges();

			// change the name column in all the rows
			foreach( DataRow row in custTable.Rows )
			{
				row["name"] = "new name";
			}
		}
		private static void Column_Changed
			( object sender, DataColumnChangeEventArgs e )
		{
			MessageBox.Show("Column_Changed Event: " + " ," +
				e.Row["name"] +" ," +e.Column.ColumnName + " ,"+ 
				e.Row["name", DataRowVersion.Original] );
		}
		private static void Column_Changing
			( object sender, DataColumnChangeEventArgs e )
		{
			MessageBox.Show("Column_Changing Event: " + " ," +
				e.Row["name"] +" ," +e.Column.ColumnName + " ,"+ 
				e.Row["name", DataRowVersion.Original] );
		}
    

		
		private static void Row_Changed
			( object sender, DataRowChangeEventArgs e )
		{
			MessageBox.Show("Row_Changed Event:" + 
				e.Row["name", DataRowVersion.Original].ToString() + 
				e.Action.ToString() );
		}
		private static void Row_Changing
			( object sender, DataRowChangeEventArgs e )
		{
			MessageBox.Show("Row_Changing Event:" + 
				e.Row["name", DataRowVersion.Original].ToString() + 
				e.Action.ToString() );
		}
    


		private void DeleteRow_Click(object sender, System.EventArgs e)
		{
			DataTable custTable = new DataTable("Customers");
			// add columns
			custTable.Columns.Add( "id", typeof(int) );
			custTable.Columns.Add( "name", typeof(string) );
			custTable.Columns.Add( "address", typeof(string) );

			// Adding RowDeleting and RowDeleted events
			custTable.RowDeleting += 
				new DataRowChangeEventHandler( Row_Deleting );
			custTable.RowDeleted += 
				new DataRowChangeEventHandler( Row_Deleted );


			// add Two rows
			custTable.Rows.Add( 
				new object[] { 1, "name1", "address1"} );
			custTable.Rows.Add( 
				new object[] { 2, "name2", "address2"} );
   
			custTable.AcceptChanges();

			// Delete all the rows
			foreach( DataRow row in custTable.Rows )
				row.Delete();
		}

		private static void Row_Deleting
			( object sender, DataRowChangeEventArgs e )
		{
			MessageBox.Show("Row_Deleting Event:" + 
				e.Row["name", DataRowVersion.Original].ToString() + 
				e.Action.ToString() );
		}
		private static void Row_Deleted
			( object sender, DataRowChangeEventArgs e )
		{
			MessageBox.Show("Row_Deleted Event:" + 
				e.Row["name", DataRowVersion.Original].ToString() + 
				e.Action.ToString() );
		}

	  private void UpdateRow_Click(object sender, System.EventArgs e)
    {
        DataTable custTable = new DataTable("Customers");
        // add columns
        custTable.Columns.Add( "id", typeof(int) );
        custTable.Columns.Add( "name", typeof(string) );
        custTable.Columns.Add( "address", typeof(string) );

                  
        // add Two rows
        custTable.Rows.Add( 
          new object[] { 1, "name1", "address1"} );
        custTable.Rows.Add( 
          new object[] { 2, "name2", "address2"} );

        custTable.AcceptChanges();

        foreach( DataRow row in custTable.Rows )
        {
          row["name"] = "new name";

          // Adding RowChanged and RowChanging event handlers
          custTable.RowChanged += 
            new DataRowChangeEventHandler( Row_Changed );
          custTable.RowChanging += 
            new DataRowChangeEventHandler( Row_Changing );
        }
      
    }

	
		

	}
}
