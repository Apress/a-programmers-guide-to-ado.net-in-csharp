using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace ConnectionEventsSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Data.OleDb.OleDbConnection oleDbConnection1;
		private System.Windows.Forms.Button button3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.button3 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(16, 40);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(112, 32);
			this.button1.TabIndex = 0;
			this.button1.Text = "Connect";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(152, 48);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(112, 32);
			this.button2.TabIndex = 1;
			this.button2.Text = "Disconnect";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.InfoMessage += new System.Data.OleDb.OleDbInfoMessageEventHandler(this.oleDbConnection1_InfoMessage);
			this.oleDbConnection1.StateChange += new System.Data.StateChangeEventHandler(this.oleDbConnection1_StateChange);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(72, 128);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(136, 40);
			this.button3.TabIndex = 2;
			this.button3.Text = "InfoMessage";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(312, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button3,
																		  this.button2,
																		  this.button1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			string strDSN = "Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source=C:\\Northwind.mdb";
			oleDbConnection1.ConnectionString = strDSN;
			try
			{
				oleDbConnection1.Open();
			}
			catch(OleDbException exp)
			{
				MessageBox.Show( exp.Message.ToString() );
			}

		}

		private void button2_Click(object sender, System.EventArgs e)
		{
		
			try
			{
				oleDbConnection1.Close(); 
			}
			catch(OleDbException exp)
			{
				MessageBox.Show( exp.Message.ToString() );
			}              

		}

		private void oleDbConnection1_InfoMessage(object sender, System.Data.OleDb.OleDbInfoMessageEventArgs e)
		{
			foreach (OleDbError err in e.Errors)
			{
				MessageBox.Show(err.Source.ToString() + err.SQLState.ToString() +
					err.NativeError.ToString() + err.Message.ToString());
			}

		}

		private void oleDbConnection1_StateChange(object sender, System.Data.StateChangeEventArgs e)
		{
			MessageBox.Show("Original State: "+ e.OriginalState.ToString() + 
				", Current State :"+ e.CurrentState.ToString() );
		
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
						
		}

		private void button3_Click(object sender, System.EventArgs e)
        {
            try
            {
                string strDSN = "Provider=Microsoft.Jet.OLEDB.4.0;"+
                    "Data Source=C:\\Northwind.mdb";
                oleDbConnection1.ConnectionString = strDSN;

                oleDbConnection1.Open();
                oleDbConnection1.ChangeDatabase("Biblio");

            }
            catch( Exception ex )
            {
                Console.WriteLine(ex.Message);
            }
            
            oleDbConnection1.Close();
            
        }
	}
}
