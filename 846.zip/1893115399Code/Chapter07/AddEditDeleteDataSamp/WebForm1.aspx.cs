using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;


namespace AddEditDeleteDataSamp
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.TextBox TextBox3;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.Button Button3;

		
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			FillDataGrid();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.TextBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Button3.Click += new System.EventHandler(this.Button3_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		

		private void FillDataGrid()
        {
            // Creating a connection 
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;"+
                "Data Source = C:\\Northwind.mdb";
            string sql = "SELECT EmployeeID, FirstName,"+
                "LastName, Title FROM Employees";

            conn.Open();

            // Creating a data adapter
            OleDbDataAdapter da = new OleDbDataAdapter(sql, conn);

    
            // Create a DataSet Object
            DataSet ds = new DataSet(); 

            // Fill DataSet with the data
            da.Fill(ds, "Employees"); 
            DataGrid1.DataSource =  ds.Tables["Employees"].DefaultView;
            DataGrid1.DataBind();
            
            conn.Close();
        }

		public bool ExecuteSQL ( string strSQL )
		{
			// Creating a connection 
			OleDbConnection conn = new OleDbConnection();
			conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source = C:\\Northwind.mdb";

			OleDbCommand myCmd = new OleDbCommand( strSQL, conn ); 

			try
			{ 
				conn.Open();
				myCmd.ExecuteNonQuery(); 
			}
			catch (Exception exp) 
			{ 
				Console.WriteLine("Insert Query Failed! {0}", exp.Message); 
				return false;
			} 
			finally 
			{
				// clean up here
				conn.Close();
			}
			return true;
		}

		// Add Button click event handler
        private void Button1_Click(object sender, System.EventArgs e)
        {
            // Build a SQL Statement
            string SQL = "INSERT INTO Employees(FirstName, LastName)"+
            " VALUES('"+TextBox2.Text.ToString()+"', '"+
            TextBox3.Text.ToString()+ "')" ;       

            // Execute SQL and refresh the data grid
            ExecuteSQL(SQL);
            FillDataGrid();     
        }

		// Edit Button click event handler
        private void Button2_Click(object sender, System.EventArgs e)
        {
            // Build a SQL Statement
            string SQL = "UPDATE Employees SET FirstName='"+
                TextBox2.Text+"', LastName='"+TextBox3.Text
                +"' WHERE EmployeeID="+TextBox1.Text ; 

            // Execute SQL and refresh the data grid
            ExecuteSQL(SQL);
            FillDataGrid();     
        }

		// Delete Button click event handler
        private void Button3_Click(object sender, System.EventArgs e)
        {
            // Build a SQL Statement
            string SQL = "DELETE * FROM Employees"+
                "WHERE EmployeeID= "+TextBox1.Text ; 

            // Execute SQL and refresh the data grid
            ExecuteSQL(SQL);
            FillDataGrid();
        
        }

		private void TextBox1_TextChanged(object sender, System.EventArgs e)
		{
		
		}


	}
}
