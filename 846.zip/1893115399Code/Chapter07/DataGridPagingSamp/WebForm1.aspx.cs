using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace DataGridPagingSamp
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
	
		private void Page_Load(object sender, System.EventArgs e)
        {
            // Create a Connection Object
            string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;"+
                "Data Source=c:\\Northwind.mdb";
            OleDbConnection conn = new OleDbConnection(ConnectionString);

            // Open the connection
            if( conn.State != ConnectionState.Open)
                conn.Open();
            // create a data adapter
            OleDbDataAdapter da = new OleDbDataAdapter
                ("SELECT FirstName, LastName, Title FROM Employees", conn);

            // Create and fill a data set
            DataSet ds = new DataSet();
            da.Fill(ds);

            // Bind data set to the control

            DataGrid1.DataSource = ds;
            DataGrid1.DataBind();
            
            // Close the connection
            if( conn.State == ConnectionState.Open)
                conn.Close();                   
            
        }

			#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DataGrid1.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DataGrid1_PageIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

			DataGrid1.PagerStyle.Mode = PagerMode.NumericPages;
			DataGrid1.PagerStyle.Mode = PagerMode.NextPrev;

			DataGrid1.PagerStyle.NextPageText = "Go to Next Page";
			DataGrid1.PagerStyle.PrevPageText = "Go to Prev Page";

			DataGrid1.PagerStyle.NextPageText = "<img srv=next.gif>";
			DataGrid1.PagerStyle.PrevPageText = "<img srv=prev.gif>";


		}
		#endregion

		private void DataGrid1_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			DataGrid1.CurrentPageIndex = e.NewPageIndex;
			DataGrid1.DataBind();
		}
	}
}
