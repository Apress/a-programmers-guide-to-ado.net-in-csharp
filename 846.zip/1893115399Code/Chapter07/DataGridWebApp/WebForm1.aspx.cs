using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;


namespace DataGridWebApp
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.Button Button1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.DataGrid1.SelectedIndexChanged += new System.EventHandler(this.DataGrid1_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			// Create a Connection Object
			string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source=c:\\Northwind.mdb";
			OleDbConnection conn = new OleDbConnection(ConnectionString);

			// Open the connection
			if( conn.State != ConnectionState.Open)
				conn.Open();
			// create a data adapter
			OleDbDataAdapter da = new OleDbDataAdapter
				("SELECT FirstName, LastName, Title FROM Employees", conn);

			// Create and fill a data set
			DataSet ds = new DataSet();
			da.Fill(ds);

			// Bind data set to the control

			DataGrid1.DataSource = ds;
			DataGrid1.DataBind();
            
			// Close the connection
			if( conn.State == ConnectionState.Open)
				conn.Close();                   

		}

		private void DataGrid1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
