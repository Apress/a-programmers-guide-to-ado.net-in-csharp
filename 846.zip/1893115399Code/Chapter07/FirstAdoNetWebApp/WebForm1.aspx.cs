using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace FirstAdoNetWebApp
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ListBox ListBox1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Create a Connection Object
			string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;"+
				"Data Source=c:\\Northwind.mdb";
			OleDbConnection conn = new OleDbConnection(ConnectionString);

			// Open the connection
			if( conn.State != ConnectionState.Open)
				conn.Open();
			// create a data adapter
			OleDbDataAdapter da = new OleDbDataAdapter
				("SELECT FirstName, LastName, Title FROM Employees", conn);

			// Create and fill a data set
			DataSet ds = new DataSet();
			da.Fill(ds);

			// Bind data set to the control
			// Set DataSource property of ListBox as DataSet�s DefaultView
			ListBox1.DataSource = ds;
			ListBox1.SelectedIndex = 0;
			// Set Field Name you want to get data from
			ListBox1.DataTextField = "FirstName";

			DataBind();

			// Close the connection
			if( conn.State == ConnectionState.Open)
				conn.Close();         

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
