using System;
using Microsoft.Data.Odbc;

namespace FirstODBCSamp
{
    class Class1
    {
        static void Main(string[] args)
        {
            // Build a connection and SQL strings
            string connectionString 
                = @"Driver={Microsoft Access Driver (*.mdb)};DBQ=c:\Northwind.mdb";
            string SQL = "SELECT * FROM Orders";


            // Create connection object
            OdbcConnection  conn = new OdbcConnection(connectionString);
        
        
            // Create command object
            OdbcCommand cmd = new OdbcCommand(SQL);
            cmd.Connection = conn;
    
            // Open connection
            conn.Open();

            // Call command's ExecuteReader
            OdbcDataReader reader = cmd.ExecuteReader();

            // Read the reader and display results on the console
            while (reader.Read()) 
            {
                Console.Write("OrderID:"+reader.GetInt32(0).ToString() );
                Console.Write(" ,");
                Console.WriteLine("Customer:" + reader.GetString(1).ToString() );
            }

            // close reader and connection
            reader.Close();
            conn.Close();



        }
    }
}
