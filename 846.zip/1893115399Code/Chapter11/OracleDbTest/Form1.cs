using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace OracleDbTest
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;
		string connString = "Provider=MSDAORA;DSN=oracle;"
			+"User ID=system;Password=manager"; 

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button CreateTableBtn;
		private System.Windows.Forms.Button ViewDataBtn;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button AddBtn;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox4;
		OleDbConnection conn = new OleDbConnection(); 

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.CreateTableBtn = new System.Windows.Forms.Button();
			this.ViewDataBtn = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.AddBtn = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(0, 128);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(368, 200);
			this.dataGrid1.TabIndex = 0;
			// 
			// CreateTableBtn
			// 
			this.CreateTableBtn.Location = new System.Drawing.Point(8, 8);
			this.CreateTableBtn.Name = "CreateTableBtn";
			this.CreateTableBtn.Size = new System.Drawing.Size(96, 24);
			this.CreateTableBtn.TabIndex = 1;
			this.CreateTableBtn.Text = "Create Table";
			this.CreateTableBtn.Click += new System.EventHandler(this.CreateTableBtn_Click);
			// 
			// ViewDataBtn
			// 
			this.ViewDataBtn.Location = new System.Drawing.Point(8, 96);
			this.ViewDataBtn.Name = "ViewDataBtn";
			this.ViewDataBtn.Size = new System.Drawing.Size(96, 24);
			this.ViewDataBtn.TabIndex = 2;
			this.ViewDataBtn.Text = "View Data";
			this.ViewDataBtn.Click += new System.EventHandler(this.ViewDataBtn_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.textBox4,
																					this.label4,
																					this.textBox3,
																					this.label3,
																					this.AddBtn,
																					this.textBox2,
																					this.label2,
																					this.textBox1,
																					this.label1});
			this.groupBox1.Location = new System.Drawing.Point(384, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(200, 288);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Add Data";
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(16, 208);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(176, 20);
			this.textBox4.TabIndex = 8;
			this.textBox4.Text = "textBox4";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 184);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(152, 24);
			this.label4.TabIndex = 7;
			this.label4.Text = "Student S. No.";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(16, 152);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(176, 20);
			this.textBox3.TabIndex = 6;
			this.textBox3.Text = "textBox3";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 128);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(160, 16);
			this.label3.TabIndex = 5;
			this.label3.Text = "Student DOB";
			// 
			// AddBtn
			// 
			this.AddBtn.Location = new System.Drawing.Point(32, 240);
			this.AddBtn.Name = "AddBtn";
			this.AddBtn.Size = new System.Drawing.Size(120, 24);
			this.AddBtn.TabIndex = 4;
			this.AddBtn.Text = "Add Data";
			this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(16, 80);
			this.textBox2.Multiline = true;
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(176, 40);
			this.textBox2.TabIndex = 3;
			this.textBox2.Text = "textBox2";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(168, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Student Address";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(16, 32);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(176, 20);
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "textBox1";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(136, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Student Name";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(592, 373);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBox1,
																		  this.ViewDataBtn,
																		  this.CreateTableBtn,
																		  this.dataGrid1});
			this.Name = "Form1";
			this.Text = "Oracle Database Sample Application";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			
		}

		private void CreateTableBtn_Click(object sender, System.EventArgs e)
		{
			// Open connection if not already open
			conn.ConnectionString = connString; 
			if( conn.State != ConnectionState.Open)
				conn.Open(); 

			//Build a CREATE TABLE string with MyId, MyName, and MyAddress tables
			string sql = "CREATE TABLE newTable (MyId INTEGER CONSTRAINT PKeyMyId PRIMARY KEY,"+
				"myName char(50), myAddress char(255) )";

			// Create a command object
			OleDbCommand cmd = new OleDbCommand(sql, conn);

			try
			{
				// Execute the SQL statement
				cmd.ExecuteNonQuery();		
			}
			catch(OleDbException ae)
			{
				string strMessage = "";
				for (int i = 0; i < ae.Errors.Count; i++)
				{
					strMessage += ae.Errors[i].Message + " - " + 
						ae.Errors[i].SQLState  + "\n";
				}
				MessageBox.Show(strMessage);
			}

			// Close connection 
			if( conn.State == ConnectionState.Open)
				conn.Close();
		
		}

		private void ViewDataBtn_Click(object sender, System.EventArgs e)
		{
			// Open connection if not already open
			conn.ConnectionString = connString; 
			if( conn.State != ConnectionState.Open)
				conn.Open(); 
		
            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM STDTABLE", conn); 
			DataSet ds = new DataSet("STDTABLE"); 
			da.Fill(ds,"STDTABLE"); 

			dataGrid1.DataSource = ds.DefaultViewManager;
			
			// Close connection 
			if( conn.State == ConnectionState.Open)
				conn.Close();
		
		}

		private void AddBtn_Click(object sender, System.EventArgs e)
		{
			string sql ="";

			// Open connection if not already open
			conn.ConnectionString = connString; 
			if( conn.State != ConnectionState.Open)
				conn.Open(); 

			sql = "INSERT INTO STDTABLE(STDNAME, STDADDRESS, STDDOB, STDSRN) "
				+"VALUES('"+textBox1.Text+"','"+textBox2.Text+"', 2/2/75, "+textBox4.Text+")" ;
			

		/*
			// Create UPDATE statement
			if(radioButton1.Checked)
			{
				sql = "UPDATE STDTABLE SET STDNAME ='"+textBox1.Text+"', STDADDRESS='"
					+textBox2.Text+"', STDDOB="+textBox3.Text
					+"WHERE STDSRN="+textBox4.Text ;	
			}

			// Create DELETE statement
			if(radioButton3.Checked)
			{
				sql = "DELETE * FROM STDTABLE WHERE STDSRN = "+textBox4.Text ;	
			}
			*/
			
			try
			{
				// Create Command object and Execute SQL statement
				OleDbCommand cmd = new OleDbCommand(sql, conn);
				cmd.ExecuteNonQuery();
			}
			catch(OleDbException ae)
			{
				string strMessage = "";
				for (int i = 0; i < ae.Errors.Count; i++)
				{
					strMessage += ae.Errors[i].Message + " - " + 
						ae.Errors[i].SQLState  + "\n";
				}
				MessageBox.Show(strMessage);
			}


			// Close connection 
			if( conn.State == ConnectionState.Open)
				conn.Close();

		
		}		
		
	}
}
