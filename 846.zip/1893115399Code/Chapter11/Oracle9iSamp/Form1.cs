using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Data.Odbc;


namespace Oracle9iSamp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;

		// Connection string for Oracle 9i
    string connString = "Driver={Oracle in OraHome90};"+
      "Server=localhost;UID=system;PWD=mahesh;";

    string sql = "SELECT * FROM OraTable";
    // Create a connection
    OdbcConnection conn = null;
    // Create a command
    OdbcCommand cmd = null;
    OdbcDataAdapter da = null;
		


		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(8, 56);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(400, 280);
			this.dataGrid1.TabIndex = 0;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 16);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(96, 24);
			this.button1.TabIndex = 1;
			this.button1.Text = "Create Table";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(112, 16);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(104, 24);
			this.button2.TabIndex = 2;
			this.button2.Text = "Fill Data";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(232, 16);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(96, 24);
			this.button3.TabIndex = 3;
			this.button3.Text = "Delete Table";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(440, 357);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																																	this.button3,
																																	this.button2,
																																	this.button1,
																																	this.dataGrid1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			// Create a connection and command
			conn = new OdbcConnection(connString);
			cmd = new OdbcCommand(sql, conn);
		}

		private void button1_Click(object sender, System.EventArgs e)
    {
    
      try
      {

        if( conn.State != ConnectionState.Open)
          conn.Open(); 

        string sql = "CREATE TABLE myTable"+
          "(Id INTEGER CONSTRAINT PKeyMyId PRIMARY KEY,"+
          "Name CHAR(50), Address CHAR(255), Zip INTEGER)" ;

                
        cmd = new OdbcCommand(sql, conn);
        cmd.ExecuteNonQuery();      
              
        // Adding records the table
        sql = "INSERT INTO myTable(Id, Name, Address, Zip) "+
          "VALUES (1001, 'Mr. Galler Hall', "+
          "'23 Church Street, Pace City, NY', 32432 ) " ;
        cmd = new OdbcCommand(sql, conn);
        cmd.ExecuteNonQuery();  

        sql = "INSERT INTO myTable(Id, Name, Address, Zip) "+
          "VALUES (1002, 'Dr. Dex Leech',"+
          "'3rd Aven, President Road, NJ', 743623) " ;
        cmd = new OdbcCommand(sql, conn);
        cmd.ExecuteNonQuery();  


        sql = "INSERT INTO myTable(Id, Name, Address, Zip) "+
          "VALUES (1003, 'Lambert Mart', "+
          "'45 Petersburgh Ave, Jacksonville, GA', 53492) " ;
        cmd = new OdbcCommand(sql, conn);
        cmd.ExecuteNonQuery();  

        sql = "INSERT INTO myTable(Id, Name, Address, Zip) "+
          "VALUES (1004, 'Moann Texur', "+
          "'4th Street, Lane 3, Packville, PA', 23433) " ;
        cmd = new OdbcCommand(sql, conn);
        cmd.ExecuteNonQuery();      
  
        // Close connection 
        if( conn.State == ConnectionState.Open)
          conn.Close();   

      }
      catch(OdbcException ae)
      {
        MessageBox.Show(ae.Message.ToString());
      }
    }

		private void button2_Click(object sender, System.EventArgs e)
    {

      try
      {
        if( conn.State != ConnectionState.Open)
          conn.Open(); 

        da = new OdbcDataAdapter("SELECT * FROM myTable", conn); 
        DataSet ds = new DataSet("ds"); 
        da.Fill(ds,"myTable"); 

        dataGrid1.DataSource = ds.DefaultViewManager; 

        // Close connection 
        if( conn.State == ConnectionState.Open)
          conn.Close();     
      }
      catch(OdbcException ae)
      {
        MessageBox.Show(ae.Message.ToString());
      }
    
    }

		private void button3_Click(object sender, System.EventArgs e)
    {
      try
      {

        if( conn.State != ConnectionState.Open)
          conn.Open(); 

        // Construct DROP TABLE query and execute it
        string sql = "DROP TABLE myTable";                
        cmd = new OdbcCommand(sql, conn);
        cmd.ExecuteNonQuery();                    
  
        // Close connection 
        if( conn.State == ConnectionState.Open)
          conn.Close();   

      }
      catch(OdbcException ae)
      {
        MessageBox.Show(ae.Message.ToString());
      }   
    }

		}			
}
